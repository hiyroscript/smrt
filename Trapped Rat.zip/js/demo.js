/* ---- demo.js ----
   DEMO: the live gameplay behind the home screen. It plays real levels with the solver's routes (SOLVER.route: the
   committed fastest route, replayed tick for tick in the real sim, so the rat slides, its tail swings, the trail
   paints and every obstacle moves exactly as in play), holds on the cheese for a moment, then moves on to the next
   level in its list. The renderer washes it with paper so the menu stays readable. Paused while another screen is
   open. */
(function (root) {
  "use strict";
  const SIM = root.SIM, SOLVER = root.SOLVER, LEVELS = root.LEVELS, RENDER = root.RENDER, HZ = SIM.HZ;
  /* a tour that shows a bit of everything, gentle first */
  const TOUR = [1, 3, 7, 11, 13, 9, 15, 17, 19, 23, 21, 25, 27, 29, 5];
  const HOLD = 1.4;   /* seconds on the cheese before the next level */
  const D = { on: false, paused: false, i: -1, L: null, st: null, route: null, m: 0, wait: 0, acc: 0, hold: 0, cache: {} };

  function load(n) {
    if (!D.cache[n]) { const L = SIM.compile(LEVELS[n - 1]); D.cache[n] = { L: L, route: SOLVER.route(L) }; }
    return D.cache[n];
  }
  function next() {
    D.i = (D.i + 1) % TOUR.length;
    const c = load(TOUR[D.i]);
    D.L = c.L; D.route = c.route; D.st = SIM.newState(D.L); D.m = 0; D.wait = 0; D.acc = 0; D.hold = 0;
    RENDER.setLevel(D.L);
  }
  function start(fromLevel) {
    D.on = true; D.paused = false;
    if (fromLevel) { const k = TOUR.indexOf(fromLevel); D.i = (k >= 0 ? k : D.i) - 1; }
    if (!D.L || fromLevel) next(); else RENDER.setLevel(D.L);
  }
  function tick() {
    const st = D.st, L = D.L;
    if (st.out) return;
    if (!st.sl) {
      const mv = D.route[D.m];
      if (!mv) { st.out = "bad"; return; }
      if (D.wait >= mv[0]) { SIM.move(L, st, mv[1]); D.m++; D.wait = 0; }
      else D.wait++;
    }
    SIM.step(L, st);
  }
  function update(dt) {
    if (!D.on || D.paused || !D.st) return;
    if (D.st.out) { D.hold += dt; if (D.hold > HOLD) next(); return; }
    D.acc += dt;
    let n = 0;
    while (D.acc >= 1 / HZ && n++ < 6) { D.acc -= 1 / HZ; tick(); if (D.st.out) break; }
    if (D.acc > 0.25) D.acc = 0;
    if (D.st.ev) {
      for (const e of D.st.ev) {
        if (e.e === "stop") { const p = SIM.ratPos(D.L, D.st, 0); RENDER.emit(p[0] + 0.5 + SIM.DX[e.d] * 0.35, p[1] + 0.5 + SIM.DY[e.d] * 0.35, 5, { sp: 1.6, life: 0.4, sz: 0.05 }); }
        else if (e.e === "win") { const p = SIM.ratPos(D.L, D.st, 0); RENDER.emit(p[0] + 0.5, p[1] + 0.5, 18, { sp: 3, life: 0.8, sz: 0.06, col: "#FFC83A" }); }
      }
      D.st.ev.length = 0;
    }
  }
  function draw(t, dt) {
    if (!D.st) return;
    RENDER.frame({ st: D.st, sub: D.st.out ? 0 : D.acc * HZ, t: t, dt: dt, home: true, won: D.st.out === "win", wonT: D.hold, noShake: true });
  }
  root.DEMO = { start: start, update: update, draw: draw, pause: function (v) { D.paused = !!v; }, stop: function () { D.on = false; }, get level() { return D.L; }, TOUR: TOUR };
})(this);
