/* ---- render.js ----
   RENDER: everything on the canvas. The maze (walls and floor) is drawn once per level and size into an offscreen
   layer; each frame draws it, then the trail, the obstacles, the cheese, the rat with its rope tail, and particles.
   World units are tiles (tile (x, y) spans x..x+1); the view fits the maze between the HUD and the safe area, and
   turns it a quarter when that gives bigger tiles (a tall maze on a landscape screen). Input directions go through
   the same turn (toGrid). Reads the sim state, never changes it. */
(function (root) {
  "use strict";
  const SIM = root.SIM, K = SIM.K, DX = SIM.DX, DY = SIM.DY, HZ = SIM.HZ;
  const COL = {
    bg: "#E6E9EE", wall: "#13131C", body: "#C3CAD4", rim: "#0A0A10", floor: "#FFFFFF", floorEdge: "rgba(10,10,16,.07)",
    trail: "#FFB21A", trailEdge: "#F09A0C", ink: "#0A0A10",
    ids: ["#2F80ED", "#9B51E0", "#16A34A", "#E11D74"]
  };
  const RM = !!(root.matchMedia && root.matchMedia("(prefers-reduced-motion: reduce)").matches);
  let cv = null, g = null, W = 0, H = 0, dpr = 1, quality = 1;
  let L = null, layer = null, lay = null, imgs = {};
  let shake = 0;
  const parts = [];
  const view = { rot: 0, ts: 32, ox: 0, oy: 0, top: 0, bot: 0, home: false };
  const anim = { ang: Math.PI, fans: [], gates: [], tail: null, lastT: 0, hit: null, snap: null };

  function init(canvas, images) { cv = canvas; g = cv.getContext("2d"); imgs = images; resize(); }
  function resize() {
    W = root.innerWidth; H = root.innerHeight;
    dpr = Math.min(root.devicePixelRatio || 1, 2) * quality;
    cv.width = Math.round(W * dpr); cv.height = Math.round(H * dpr);
    if (L) layout();
  }
  /* insets: the space the HUD (top) and the safe area (bottom) take, in CSS px */
  function setInsets(top, bot, home) { view.top = top; view.bot = bot; view.home = !!home; if (L) layout(); }
  function layout() {
    const pad = view.home ? Math.min(W, H) * 0.04 : Math.max(10, Math.min(W, H) * 0.03);
    const aw = W - pad * 2, ah = H - view.top - view.bot - pad * 2;
    const t0 = Math.min(aw / L.w, ah / L.h), t1 = Math.min(aw / L.h, ah / L.w);
    view.rot = t1 > t0 * 1.08 ? 1 : 0;
    view.ts = Math.max(4, Math.floor(view.rot ? t1 : t0));
    if (view.home) view.ts = Math.min(view.ts, Math.round(Math.min(W, H) / 7));   /* the demo stays a board, not a close-up */
    const vw = (view.rot ? L.h : L.w) * view.ts, vh = (view.rot ? L.w : L.h) * view.ts;
    view.ox = Math.round(pad + (aw - vw) / 2); view.oy = Math.round(view.top + pad + (ah - vh) / 2);
    buildLayer();
  }
  function setLevel(level) {
    L = level; anim.fans = L.fans.map(function (f) { return f.d * Math.PI / 2; }); anim.gates = L.gates.map(function () { return 0; });
    anim.tail = null; anim.hit = null; anim.snap = null; parts.length = 0; shake = 0;
    layout();
  }
  /* screen swipe (dx, dy) -> grid direction, through the view's turn */
  function toGrid(dx, dy) {
    if (view.rot) { const t = dx; dx = dy; dy = -t; }
    return Math.abs(dx) > Math.abs(dy) ? (dx > 0 ? 1 : 3) : (dy > 0 ? 2 : 0);
  }
  function mazeRect() { const vw = (view.rot ? L.h : L.w) * view.ts, vh = (view.rot ? L.w : L.h) * view.ts; return { x: view.ox, y: view.oy, w: vw, h: vh }; }
  function worldToScreen(x, y) { return view.rot ? [view.ox + (L.h - y) * view.ts, view.oy + x * view.ts] : [view.ox + x * view.ts, view.oy + y * view.ts]; }

  /* ---------------- the static maze layer ---------------- */
  const isMask = function (x, y) { return x >= 0 && y >= 0 && x < L.w && y < L.h && L.g[y * L.w + x] !== 0; };
  const isFloor = function (x, y) { return x >= 0 && y >= 0 && x < L.w && y < L.h && L.g[y * L.w + x] === 2; };
  function rrect(c, x, y, w, h, r) {   /* r: [tl, tr, br, bl] */
    c.beginPath();
    c.moveTo(x + r[0], y); c.lineTo(x + w - r[1], y); if (r[1]) c.arcTo(x + w, y, x + w, y + r[1], r[1]); else c.lineTo(x + w, y);
    c.lineTo(x + w, y + h - r[2]); if (r[2]) c.arcTo(x + w, y + h, x + w - r[2], y + h, r[2]); else c.lineTo(x + w, y + h);
    c.lineTo(x + r[3], y + h); if (r[3]) c.arcTo(x, y + h, x, y + h - r[3], r[3]); else c.lineTo(x, y + h);
    c.lineTo(x, y + r[0]); if (r[0]) c.arcTo(x, y, x + r[0], y, r[0]); else c.lineTo(x, y);
    c.closePath();
  }
  function corners(test, x, y, rad) {
    return [!test(x - 1, y) && !test(x, y - 1) ? rad : 0, !test(x + 1, y) && !test(x, y - 1) ? rad : 0,
      !test(x + 1, y) && !test(x, y + 1) ? rad : 0, !test(x - 1, y) && !test(x, y + 1) ? rad : 0];
  }
  function buildLayer() {
    const ts = view.ts, m = Math.ceil(ts * 0.8), pw = L.w * ts + m * 2, ph = L.h * ts + m * 2;
    if (!layer) { layer = document.createElement("canvas"); lay = layer.getContext("2d"); }
    layer.width = Math.round(pw * dpr); layer.height = Math.round(ph * dpr); layer.m = m;
    const c = lay;
    c.setTransform(dpr, 0, 0, dpr, m * dpr, m * dpr); c.clearRect(-m, -m, pw, ph);
    /* the shape: one ink silhouette with a soft shadow, outer corners rounded */
    c.save();
    c.shadowColor = "rgba(10,10,16,.22)"; c.shadowBlur = ts * 0.6; c.shadowOffsetY = ts * 0.12;
    c.fillStyle = COL.wall;
    for (let y = 0; y < L.h; y++) for (let x = 0; x < L.w; x++) if (isMask(x, y)) { rrect(c, x * ts - 0.5, y * ts - 0.5, ts + 1, ts + 1, corners(isMask, x, y, ts * 0.32)); c.fill(); }
    c.restore();
    c.fillStyle = COL.wall;
    for (let y = 0; y < L.h; y++) for (let x = 0; x < L.w; x++) if (isMask(x, y)) { rrect(c, x * ts - 0.5, y * ts - 0.5, ts + 1, ts + 1, corners(isMask, x, y, ts * 0.32)); c.fill(); }
    /* walls away from any corridor are the block's body, a soft grey: only walls that touch the floor stay ink, so the
       corridors read as cut into the shape */
    const near = function (x, y) { for (let dy = -1; dy <= 1; dy++) for (let dx = -1; dx <= 1; dx++) if (isFloor(x + dx, y + dy)) return true; return false; };
    const deep = function (x, y) { return isMask(x, y) && !isFloor(x, y) && !near(x, y); };
    c.fillStyle = COL.body;
    for (let y = 0; y < L.h; y++) for (let x = 0; x < L.w; x++) if (deep(x, y)) {
      const r = ts * 0.3, cr = [!deep(x - 1, y) && !deep(x, y - 1) ? r : 0, !deep(x + 1, y) && !deep(x, y - 1) ? r : 0, !deep(x + 1, y) && !deep(x, y + 1) ? r : 0, !deep(x - 1, y) && !deep(x, y + 1) ? r : 0];
      /* round only where the grey meets the ink inside the shape; the shape's own outline keeps its rounding */
      const outer = corners(isMask, x, y, ts * 0.32);
      for (let k = 0; k < 4; k++) if (outer[k]) cr[k] = outer[k];
      rrect(c, x * ts + ts * 0.06 * (deep(x - 1, y) ? -1 : 1) * (isMask(x - 1, y) ? 1 : 0), y * ts + ts * 0.06 * (deep(x, y - 1) ? -1 : 1) * (isMask(x, y - 1) ? 1 : 0),
        ts - ts * 0.06 * ((deep(x - 1, y) ? -1 : 1) * (isMask(x - 1, y) ? 1 : 0) + (deep(x + 1, y) ? -1 : 1) * (isMask(x + 1, y) ? 1 : 0)),
        ts - ts * 0.06 * ((deep(x, y - 1) ? -1 : 1) * (isMask(x, y - 1) ? 1 : 0) + (deep(x, y + 1) ? -1 : 1) * (isMask(x, y + 1) ? 1 : 0)), cr);
      c.fill();
    }
    /* floor, convex corners rounded */
    c.fillStyle = COL.floor;
    for (let y = 0; y < L.h; y++) for (let x = 0; x < L.w; x++) if (isFloor(x, y)) { rrect(c, x * ts - 0.25, y * ts - 0.25, ts + 0.5, ts + 0.5, corners(isFloor, x, y, ts * 0.26)); c.fill(); }
    /* a faint tile grid on the floor: the slides read as tile steps, and floor never looks like the page */
    c.fillStyle = "rgba(10,10,16,.05)";
    const dot = Math.max(1.2, ts * 0.045);
    for (let y = 0; y <= L.h; y++) for (let x = 0; x <= L.w; x++) {
      if (isFloor(x, y) && isFloor(x - 1, y) && isFloor(x, y - 1) && isFloor(x - 1, y - 1)) { c.beginPath(); c.arc(x * ts, y * ts, dot, 0, Math.PI * 2); c.fill(); }
    }
    c.strokeStyle = "rgba(10,10,16,.045)"; c.lineWidth = Math.max(1, ts * 0.025);
    for (let y = 0; y < L.h; y++) for (let x = 0; x < L.w; x++) {
      if (!isFloor(x, y)) continue;
      if (isFloor(x + 1, y)) { c.beginPath(); c.moveTo((x + 1) * ts, y * ts + ts * 0.3); c.lineTo((x + 1) * ts, y * ts + ts * 0.7); c.stroke(); }
      if (isFloor(x, y + 1)) { c.beginPath(); c.moveTo(x * ts + ts * 0.3, (y + 1) * ts); c.lineTo(x * ts + ts * 0.7, (y + 1) * ts); c.stroke(); }
    }
    /* a faint inner shadow under walls above and to the left, for depth */
    c.fillStyle = COL.floorEdge;
    for (let y = 0; y < L.h; y++) for (let x = 0; x < L.w; x++) {
      if (!isFloor(x, y)) continue;
      if (!isFloor(x, y - 1)) c.fillRect(x * ts + (isFloor(x - 1, y) ? 0 : ts * 0.1), y * ts, ts - (isFloor(x - 1, y) ? 0 : ts * 0.1) - (isFloor(x + 1, y) ? 0 : ts * 0.1), Math.max(1.5, ts * 0.07));
      if (!isFloor(x - 1, y)) c.fillRect(x * ts, y * ts + (isFloor(x, y - 1) ? 0 : ts * 0.1), Math.max(1.5, ts * 0.06), ts - (isFloor(x, y - 1) ? 0 : ts * 0.1) - (isFloor(x, y + 1) ? 0 : ts * 0.1));
    }
    /* static floor marks: glue stains, robot lanes, the snake's track */
    for (let i = 0; i < L.N; i++) if (L.k[i] === K.GLUE) drawGlue(c, i % L.w, i / L.w | 0, ts);
    c.save(); c.setLineDash([ts * 0.08, ts * 0.16]); c.lineCap = "round"; c.lineWidth = Math.max(1, ts * 0.05); c.strokeStyle = "rgba(10,10,16,.16)";
    for (const r of L.robots) { c.beginPath(); r.pl.P.forEach(function (p, i) { const X = (p[0] + 0.5) * ts, Y = (p[1] + 0.5) * ts; if (i) c.lineTo(X, Y); else c.moveTo(X, Y); }); c.stroke(); }
    c.strokeStyle = "rgba(22,120,60,.22)";
    for (const s of L.snakes) { c.beginPath(); s.pl.P.forEach(function (p, i) { const X = (p[0] + 0.5) * ts, Y = (p[1] + 0.5) * ts; if (i) c.lineTo(X, Y); else c.moveTo(X, Y); }); c.stroke(); }
    c.restore();
  }

  /* ---------------- obstacle drawings (world tile coords, scale 1 = a tile) ---------------- */
  function drawGlue(c, x, y, ts) {   /* sticky grey-lilac goo with a few strands, nothing like the cheese */
    const cx = (x + 0.5) * ts, cy = (y + 0.5) * ts, r = ts * 0.42;
    c.save(); c.fillStyle = "rgba(150,128,190,.62)"; c.beginPath();
    for (let a = 0; a <= 14; a++) { const t = a / 14 * Math.PI * 2, rr = r * (0.84 + 0.16 * Math.sin(t * 3 + x * 1.7 + y)); c.lineTo(cx + Math.cos(t) * rr, cy + Math.sin(t) * rr); }
    c.closePath(); c.fill();
    c.strokeStyle = "rgba(96,74,140,.55)"; c.lineWidth = Math.max(1, ts * 0.03); c.stroke();
    c.strokeStyle = "rgba(255,255,255,.55)"; c.lineWidth = Math.max(1, ts * 0.025); c.lineCap = "round";
    for (const q of [[-0.2, -0.05, 0.05, 0.12], [0.05, -0.22, 0.2, 0.02], [-0.05, 0.12, 0.18, 0.22]]) { c.beginPath(); c.moveTo(cx + q[0] * ts, cy + q[1] * ts); c.quadraticCurveTo(cx + (q[0] + q[2]) * ts / 2, cy + (q[1] + q[3]) * ts / 2 + ts * 0.06, cx + q[2] * ts, cy + q[3] * ts); c.stroke(); }
    c.fillStyle = "rgba(255,255,255,.6)"; c.beginPath(); c.ellipse(cx - r * 0.35, cy - r * 0.4, r * 0.16, r * 0.09, -0.5, 0, Math.PI * 2); c.fill();
    c.restore();
  }
  function cxy(i) { return [i % L.w + 0.5, (i / L.w | 0) + 0.5]; }
  function rot(d) { return [-Math.PI / 2, 0, Math.PI / 2, Math.PI][d]; }   /* the angle of a grid direction */
  function drawTrap(c, i, snapped) {
    const p = cxy(i);
    c.save(); c.translate(p[0], p[1]);
    c.fillStyle = "#D9A066"; c.strokeStyle = "#8A5A2B"; c.lineWidth = 0.04;
    rrect(c, -0.36, -0.27, 0.72, 0.54, [0.06, 0.06, 0.06, 0.06]); c.fill(); c.stroke();
    c.strokeStyle = "rgba(138,90,43,.45)"; c.lineWidth = 0.02; c.beginPath(); c.moveTo(-0.3, -0.1); c.lineTo(0.3, -0.1); c.moveTo(-0.3, 0.1); c.lineTo(0.3, 0.1); c.stroke();
    c.fillStyle = "#E23B3B"; c.fillRect(0.02, -0.08, 0.16, 0.16);
    c.strokeStyle = "#AEB4BD"; c.lineWidth = 0.055; c.lineCap = "round"; c.beginPath();
    if (snapped) { c.moveTo(-0.05, -0.22); c.lineTo(0.3, -0.22); c.lineTo(0.3, 0.22); c.lineTo(-0.05, 0.22); }
    else { c.moveTo(-0.05, -0.22); c.lineTo(-0.3, -0.22); c.lineTo(-0.3, 0.22); c.lineTo(-0.05, 0.22); }
    c.stroke();
    c.strokeStyle = "#7D848F"; c.lineWidth = 0.035; c.beginPath(); c.arc(-0.05, 0, 0.07, 0, Math.PI * 2); c.stroke();
    c.restore();
  }
  function drawPuddle(c, i, t) {
    const p = cxy(i);
    c.save(); c.translate(p[0], p[1]);
    c.fillStyle = "rgba(64,150,230,.82)"; c.beginPath();
    for (let a = 0; a <= 16; a++) { const q = a / 16 * Math.PI * 2, rr = 0.42 * (0.9 + 0.1 * Math.sin(q * 3 + i)); c.lineTo(Math.cos(q) * rr, Math.sin(q) * rr * 0.92); }
    c.closePath(); c.fill();
    c.strokeStyle = "rgba(255,255,255,.6)"; c.lineWidth = 0.03;
    const ph = RM ? 0.4 : (t * 0.6 + i * 0.37) % 1;
    c.beginPath(); c.ellipse(0, 0, 0.08 + ph * 0.28, (0.08 + ph * 0.28) * 0.8, 0, 0, Math.PI * 2); c.globalAlpha = 1 - ph; c.stroke();
    c.globalAlpha = 1; c.fillStyle = "rgba(255,255,255,.45)"; c.beginPath(); c.ellipse(-0.14, -0.16, 0.1, 0.05, -0.4, 0, Math.PI * 2); c.fill();
    c.restore();
  }
  function drawCrack(c, i, broken) {
    const p = cxy(i);
    c.save(); c.translate(p[0], p[1]);
    if (broken) {
      c.fillStyle = "#24242E"; rrect(c, -0.44, -0.44, 0.88, 0.88, [0.14, 0.14, 0.14, 0.14]); c.fill();
      c.fillStyle = "#3A3A48"; for (const q of [[-0.25, -0.2, 0.1], [0.2, -0.24, 0.08], [0.18, 0.2, 0.11], [-0.2, 0.22, 0.07], [0, 0, 0.05]]) { c.beginPath(); c.arc(q[0], q[1], q[2], 0, Math.PI * 2); c.fill(); }
    } else {
      c.strokeStyle = "rgba(10,10,16,.55)"; c.lineWidth = 0.035; c.lineJoin = "round"; c.beginPath();
      c.moveTo(-0.42, -0.1); c.lineTo(-0.15, 0.02); c.lineTo(0.02, -0.12); c.lineTo(0.2, 0.1); c.lineTo(0.42, 0.04);
      c.moveTo(0.02, -0.12); c.lineTo(-0.04, -0.42); c.moveTo(-0.15, 0.02); c.lineTo(-0.1, 0.4); c.moveTo(0.2, 0.1); c.lineTo(0.12, 0.42);
      c.stroke();
    }
    c.restore();
  }
  function drawConv(c, cv0, t) {
    const p = cxy(cv0.i);
    c.save(); c.translate(p[0], p[1]); c.rotate(rot(cv0.d));
    c.fillStyle = "rgba(74,80,92,.9)"; rrect(c, -0.42, -0.42, 0.84, 0.84, [0.08, 0.08, 0.08, 0.08]); c.fill();
    c.beginPath(); c.rect(-0.42, -0.42, 0.84, 0.84); c.clip();
    c.strokeStyle = "#FFFFFF"; c.lineWidth = 0.07; c.lineCap = "round"; c.lineJoin = "round";
    const off = RM ? 0 : (t * 1.4) % 0.34;
    for (let k = -2; k <= 2; k++) { const x = k * 0.34 + off; c.globalAlpha = 0.85; c.beginPath(); c.moveTo(x - 0.1, -0.18); c.lineTo(x + 0.06, 0); c.lineTo(x - 0.1, 0.18); c.stroke(); }
    c.restore();
  }
  function drawPortal(c, i, colr, t) {
    const p = cxy(i);
    c.save(); c.translate(p[0], p[1]);
    c.fillStyle = colr; c.beginPath(); c.ellipse(0, 0.02, 0.42, 0.38, 0, 0, Math.PI * 2); c.fill();
    c.fillStyle = "#14141C"; c.beginPath(); c.ellipse(0, 0.04, 0.32, 0.28, 0, 0, Math.PI * 2); c.fill();
    c.strokeStyle = colr; c.globalAlpha = 0.7; c.lineWidth = 0.04; c.lineCap = "round";
    const a0 = RM ? 0 : t * 2.4;
    for (let k = 0; k < 3; k++) { c.beginPath(); c.arc(0, 0.04, 0.08 + k * 0.07, a0 + k * 2.1, a0 + k * 2.1 + 2.2); c.stroke(); }
    c.restore();
  }
  function drawPlate(c, pl, pressed) {
    const p = cxy(pl.i), colr = COL.ids[pl.id % COL.ids.length];
    c.save(); c.translate(p[0], p[1]);
    c.fillStyle = "rgba(10,10,16,.12)"; rrect(c, -0.34, -0.34, 0.68, 0.68, [0.1, 0.1, 0.1, 0.1]); c.fill();
    c.fillStyle = colr; const s = pressed ? 0.24 : 0.29;
    rrect(c, -s, -s + (pressed ? 0.02 : -0.02), s * 2, s * 2, [0.08, 0.08, 0.08, 0.08]); c.fill();
    if (!pressed) { c.fillStyle = "rgba(255,255,255,.35)"; c.fillRect(-s + 0.05, -s, s * 2 - 0.1, 0.06); }
    c.restore();
  }
  function drawGate(c, gt, open) {
    const p = cxy(gt.i), colr = COL.ids[gt.id % COL.ids.length];
    c.save(); c.translate(p[0], p[1]); if (gt.ax === 0) c.rotate(Math.PI / 2);
    /* bars across the way, sliding into the walls as it opens */
    const k = 1 - open;
    c.fillStyle = colr; c.globalAlpha = 0.25 + 0.75 * k;
    c.fillRect(-0.06, -0.5, 0.12, 0.5 * k); c.fillRect(-0.06, 0.5 - 0.5 * k, 0.12, 0.5 * k);
    c.globalAlpha = 1;
    for (const x of [-0.3, 0.3]) { c.fillStyle = colr; c.fillRect(x - 0.05, -0.5, 0.1, 0.5 * k); c.fillRect(x - 0.05, 0.5 - 0.5 * k, 0.1, 0.5 * k); }
    c.fillStyle = "#0A0A10"; c.fillRect(-0.45, -0.5, 0.9, 0.06); c.fillRect(-0.45, 0.44, 0.9, 0.06);
    c.restore();
  }
  function drawDoor(c, di, open) {
    const d = L.doors[di], p = cxy(d.i);
    c.save(); c.translate(p[0], p[1]); if (d.ax === 1) c.rotate(Math.PI / 2);
    /* a vertical corridor (ax 0): the closed door lies across it; it swings a quarter turn open about its left hinge */
    c.fillStyle = "#0A0A10"; c.beginPath(); c.arc(-0.44, 0, 0.07, 0, Math.PI * 2); c.fill();
    c.translate(-0.44, 0); c.rotate(-open * Math.PI / 2);
    c.fillStyle = "#B4783F"; c.strokeStyle = "#6E4520"; c.lineWidth = 0.035;
    rrect(c, 0, -0.08, 0.86, 0.16, [0.04, 0.04, 0.04, 0.04]); c.fill(); c.stroke();
    c.strokeStyle = "rgba(110,69,32,.5)"; c.lineWidth = 0.02; c.beginPath(); c.moveTo(0.1, 0); c.lineTo(0.78, 0); c.stroke();
    c.restore();
  }
  function drawFan(c, fi, t) {
    const f = L.fans[fi], p = cxy(f.i);
    c.save(); c.translate(p[0], p[1]);
    c.fillStyle = "#C9CED6"; c.strokeStyle = "#0A0A10"; c.lineWidth = 0.05;
    rrect(c, -0.44, -0.44, 0.88, 0.88, [0.16, 0.16, 0.16, 0.16]); c.fill(); c.stroke();
    c.fillStyle = "rgba(10,10,16,.12)"; c.beginPath(); c.arc(0, 0, 0.32, 0, Math.PI * 2); c.fill();
    c.rotate(anim.fans[fi]);
    c.fillStyle = "#FF6A13"; c.beginPath();
    c.moveTo(0.34, 0); c.lineTo(0.04, -0.26); c.lineTo(0.04, -0.1); c.lineTo(-0.28, -0.1); c.lineTo(-0.28, 0.1); c.lineTo(0.04, 0.1); c.lineTo(0.04, 0.26); c.closePath(); c.fill();
    c.restore();
    void t;
  }
  function drawEmitter(c, ls, phase, t) {
    const p = cxy(ls.e);
    c.save(); c.translate(p[0], p[1]); c.rotate(rot(ls.d));
    c.fillStyle = "#A7AEBA"; c.strokeStyle = "#5E6573"; c.lineWidth = 0.04; rrect(c, 0.08, -0.26, 0.4, 0.52, [0.08, 0.08, 0.08, 0.08]); c.fill(); c.stroke();
    c.fillStyle = "#3A3D48"; c.beginPath(); c.arc(0.46, 0, 0.13, 0, Math.PI * 2); c.fill();
    c.fillStyle = phase === 2 ? "#FF2D55" : phase === 1 && Math.floor(t * 12) % 2 ? "#FF8FA6" : "#8A2A3C";
    c.beginPath(); c.arc(0.46, 0, 0.09, 0, Math.PI * 2); c.fill();
    c.restore();
  }
  function drawBeam(c, ls, phase, t) {
    if (!ls.cells.length || phase === 0) return;
    const a = cxy(ls.e), b = cxy(ls.cells[ls.cells.length - 1]);
    const ax = a[0] + DX[ls.d] * 0.5, ay = a[1] + DY[ls.d] * 0.5, bx = b[0] + DX[ls.d] * 0.5, by = b[1] + DY[ls.d] * 0.5;
    c.save(); c.lineCap = "round";
    if (phase === 2) {
      c.strokeStyle = "rgba(255,45,85,.25)"; c.lineWidth = 0.34; c.beginPath(); c.moveTo(ax, ay); c.lineTo(bx, by); c.stroke();
      c.strokeStyle = "#FF2D55"; c.lineWidth = 0.12; c.stroke();
      c.strokeStyle = "#FFE0E6"; c.lineWidth = 0.04; c.stroke();
    } else if (Math.floor(t * 14) % 2 === 0 || RM) {
      c.setLineDash([0.12, 0.1]); c.strokeStyle = "rgba(255,45,85,.7)"; c.lineWidth = 0.035; c.beginPath(); c.moveTo(ax, ay); c.lineTo(bx, by); c.stroke();
    }
    c.restore();
  }
  function drawPaw(c, pw, ph) {
    const p = cxy(pw.i), fd = pw.from;
    c.save(); c.translate(p[0], p[1]); c.rotate(rot(fd));
    /* local frame: the slot is at x = -1 (the wall tile behind), the paw reaches along +x */
    c.fillStyle = "#6E5A48"; rrect(c, -0.72, -0.3, 0.24, 0.6, [0.08, 0.08, 0.08, 0.08]); c.fill();
    c.fillStyle = "#050508"; rrect(c, -0.66, -0.22, 0.14, 0.44, [0.05, 0.05, 0.05, 0.05]); c.fill();
    if (ph[0] === 1) {
      c.fillStyle = "rgba(10,10,16," + (0.1 + 0.22 * ph[1]) + ")";
      c.beginPath(); c.ellipse(0, 0, 0.18 + 0.2 * ph[1], 0.16 + 0.16 * ph[1], 0, 0, Math.PI * 2); c.fill();
    } else if (ph[0] === 2) {
      const reach = ph[1] < 0.25 ? ph[1] / 0.25 : ph[1] > 0.75 ? (1 - ph[1]) / 0.25 : 1, tip = -0.5 + 0.88 * reach;
      c.fillStyle = "#E8913A"; c.strokeStyle = "#7A4210"; c.lineWidth = 0.035;
      rrect(c, -0.56, -0.17, tip + 0.56, 0.34, [0.04, 0.17, 0.17, 0.04]); c.fill(); c.stroke();
      c.beginPath(); c.ellipse(tip, 0, 0.24, 0.26, 0, 0, Math.PI * 2); c.fill(); c.stroke();
      c.strokeStyle = "rgba(122,66,16,.6)"; c.lineWidth = 0.03; for (const x of [-0.4, -0.25, -0.1]) if (x < tip - 0.15) { c.beginPath(); c.moveTo(x, -0.15); c.lineTo(x + 0.05, 0.15); c.stroke(); }
      c.fillStyle = "#F7A1B5"; c.beginPath(); c.ellipse(tip - 0.02, 0, 0.1, 0.12, 0, 0, Math.PI * 2); c.fill();
      for (const q of [[0.13, -0.15], [0.17, 0], [0.13, 0.15]]) { c.beginPath(); c.arc(tip + q[0], q[1], 0.05, 0, Math.PI * 2); c.fill(); }
      c.strokeStyle = "#F4F4F6"; c.lineWidth = 0.025; for (const q of [-0.15, 0, 0.15]) { c.beginPath(); c.moveTo(tip + 0.22, q); c.lineTo(tip + 0.3, q * 1.1); c.stroke(); }
    }
    c.restore();
  }
  function drawRobot(c, x, y, a, t, chaser) {
    c.save(); c.translate(x + 0.5, y + 0.5);
    c.fillStyle = "rgba(10,10,16,.18)"; c.beginPath(); c.ellipse(0.03, 0.06, 0.42, 0.4, 0, 0, Math.PI * 2); c.fill();
    c.rotate(a);
    if (chaser) {
      c.fillStyle = "#D63A3A"; c.strokeStyle = "#5E0F0F"; c.lineWidth = 0.05;
      rrect(c, -0.38, -0.38, 0.76, 0.76, [0.2, 0.2, 0.2, 0.2]); c.fill(); c.stroke();
      c.fillStyle = "#F0F0F2"; rrect(c, 0.08, -0.24, 0.22, 0.48, [0.08, 0.08, 0.08, 0.08]); c.fill();
      c.fillStyle = "#0A0A10"; c.beginPath(); c.arc(0.2, 0, 0.08, 0, Math.PI * 2); c.fill();
      c.strokeStyle = "#5E0F0F"; c.lineWidth = 0.05; c.beginPath(); c.moveTo(0.02, -0.3); c.lineTo(0.3, -0.18); c.moveTo(0.02, 0.3); c.lineTo(0.3, 0.18); c.stroke();
    } else {
      c.fillStyle = "#3A3F4B"; c.beginPath(); c.arc(0, 0, 0.4, 0, Math.PI * 2); c.fill();
      c.fillStyle = "#555C6B"; c.beginPath(); c.arc(-0.03, 0, 0.3, 0, Math.PI * 2); c.fill();
      c.strokeStyle = "#16181D"; c.lineWidth = 0.07; c.beginPath(); c.arc(0, 0, 0.37, -1.0, 1.0); c.stroke();
      c.fillStyle = Math.floor(t * 3) % 2 ? "#36E27A" : "#1E8A49"; c.beginPath(); c.arc(0.16, 0, 0.05, 0, Math.PI * 2); c.fill();
      c.strokeStyle = "rgba(220,224,230,.8)"; c.lineWidth = 0.025;
      const sp = RM ? 0 : t * 14;
      for (const side of [-1, 1]) { const bx = 0.28, by = side * 0.26; for (let k = 0; k < 3; k++) { const q = sp * side + k * 2.09; c.beginPath(); c.moveTo(bx, by); c.lineTo(bx + Math.cos(q) * 0.13, by + Math.sin(q) * 0.13); c.stroke(); } }
    }
    c.restore();
  }
  function drawSnake(c, segs, t) {
    c.save();
    for (let i = segs.length - 1; i >= 0; i--) {
      const s = segs[i], r = i === 0 ? 0.36 : 0.32 - i * 0.025;
      c.fillStyle = i % 2 ? "#3FAF5B" : "#4BC468"; c.strokeStyle = "#1B5E30"; c.lineWidth = 0.05;
      c.beginPath(); c.arc(s[0] + 0.5, s[1] + 0.5, r, 0, Math.PI * 2); c.fill(); c.stroke();
    }
    const h = segs[0], a = h[2];
    c.translate(h[0] + 0.5, h[1] + 0.5); c.rotate(a);
    if (!RM && Math.floor(t * 4) % 3 === 0) { c.strokeStyle = "#E0294A"; c.lineWidth = 0.03; c.beginPath(); c.moveTo(0.32, 0); c.lineTo(0.5, 0); c.lineTo(0.56, -0.05); c.moveTo(0.5, 0); c.lineTo(0.56, 0.05); c.stroke(); }
    for (const side of [-1, 1]) { c.fillStyle = "#FFF"; c.beginPath(); c.arc(0.14, side * 0.15, 0.08, 0, Math.PI * 2); c.fill(); c.fillStyle = "#0A0A10"; c.beginPath(); c.arc(0.17, side * 0.15, 0.04, 0, Math.PI * 2); c.fill(); }
    c.restore();
  }

  /* ---------------- the rat and its tail ---------------- */
  const TAIL_N = 11, TAIL_SEG = 0.072;
  function tailStep(rx, ry, ang, dt, t, moving) {
    const fx = -Math.sin(ang), fy = Math.cos(ang);       /* the nose direction (the sprite faces down at angle 0) */
    const ax = rx - fx * 0.46, ay = ry - fy * 0.46;     /* the rump */
    let T = anim.tail;
    if (!T) { T = anim.tail = []; for (let i = 0; i < TAIL_N; i++) T.push([ax - fx * TAIL_SEG * i, ay - fy * TAIL_SEG * i]); }
    T[0][0] = ax; T[0][1] = ay;
    const px = -fy, py = fx;
    const k = Math.min(1, dt * (moving ? 2.5 : 7));
    for (let i = 1; i < TAIL_N; i++) {
      /* rest pose: straight back from the rump, swaying gently; moving, the rope just trails */
      const sway = RM ? 0 : Math.sin(t * 2.3 - i * 0.55) * 0.045 * (i / TAIL_N) * (moving ? 0.3 : 1) * TAIL_N * 0.35;
      const tx = ax - fx * TAIL_SEG * i + px * sway, ty = ay - fy * TAIL_SEG * i + py * sway;
      T[i][0] += (tx - T[i][0]) * k * (0.5 + i / TAIL_N); T[i][1] += (ty - T[i][1]) * k * (0.5 + i / TAIL_N);
    }
    for (let it = 0; it < 2; it++) for (let i = 1; i < TAIL_N; i++) {   /* rope: keep each link its length */
      const a = T[i - 1], b = T[i], dx = b[0] - a[0], dy = b[1] - a[1], d = Math.hypot(dx, dy) || 1e-6;
      b[0] = a[0] + dx / d * TAIL_SEG; b[1] = a[1] + dy / d * TAIL_SEG;
    }
  }
  function drawTail(c) {
    const T = anim.tail; if (!T) return;
    c.save(); c.lineCap = "round"; c.lineJoin = "round";
    const wAt = function (i) { return 0.11 * (1 - i / TAIL_N) + 0.022; };
    for (let i = 1; i < TAIL_N; i++) { c.strokeStyle = "#141018"; c.lineWidth = wAt(i - 1) + 0.045; c.beginPath(); c.moveTo(T[i - 1][0], T[i - 1][1]); c.lineTo(T[i][0], T[i][1]); c.stroke(); }
    for (let i = 1; i < TAIL_N; i++) {
      const f = i / TAIL_N, r = Math.round(232 + (217 - 232) * f), gg = Math.round(169 + (140 - 169) * f), b = Math.round(174 + (147 - 174) * f);
      c.strokeStyle = "rgb(" + r + "," + gg + "," + b + ")"; c.lineWidth = wAt(i - 1);
      c.beginPath(); c.moveTo(T[i - 1][0], T[i - 1][1]); c.lineTo(T[i][0], T[i][1]); c.stroke();
    }
    c.restore();
  }
  function drawRat(c, x, y, ang, sc, squash) {
    const im = imgs.rat; if (!im || !im.complete || !im.naturalWidth) return;
    const h = 1.12 * sc, w = h * im.naturalWidth / im.naturalHeight;
    c.save(); c.translate(x, y); c.rotate(ang);
    c.fillStyle = "rgba(10,10,16,.16)"; c.beginPath(); c.ellipse(0.04, 0.06, w * 0.46, h * 0.44, 0, 0, Math.PI * 2); c.fill();
    c.scale(1 + squash * 0.12, 1 - squash * 0.12);
    c.drawImage(im, -w / 2, -h / 2, w, h);
    c.restore();
  }
  function drawCheese(c, i, t, gone) {
    const im = imgs.cheese; if (!im || !im.complete || !im.naturalWidth) return;
    const p = cxy(i), bob = RM ? 0 : Math.sin(t * 2.6) * 0.045, s = gone ? Math.max(0, 1 - gone * 3) : 1;
    if (s <= 0) return;
    c.save(); c.translate(p[0], p[1]); if (view.rot) c.rotate(-Math.PI / 2); c.translate(0, bob);   /* upright on a turned board */
    const gl = c.createRadialGradient(0, 0, 0.05, 0, 0, 0.62);
    gl.addColorStop(0, "rgba(255,206,64," + (0.55 + 0.15 * Math.sin(t * 3)) + ")"); gl.addColorStop(1, "rgba(255,206,64,0)");
    c.fillStyle = gl; c.beginPath(); c.arc(0, 0, 0.62, 0, Math.PI * 2); c.fill();
    const w = 0.84 * s, h = w * im.naturalHeight / im.naturalWidth;
    c.drawImage(im, -w / 2, -h / 2 - 0.02, w, h);
    c.restore();
  }

  /* ---------------- particles and effects ---------------- */
  function emit(x, y, n, o) {
    if (RM) n = Math.ceil(n / 3);
    for (let i = 0; i < n; i++) {
      const a = (o.ang !== undefined ? o.ang : Math.random() * Math.PI * 2) + (Math.random() - 0.5) * (o.spread || Math.PI * 2), sp = (o.sp || 2) * (0.4 + Math.random() * 0.8);
      parts.push({ x: x, y: y, vx: Math.cos(a) * sp, vy: Math.sin(a) * sp, life: o.life || 0.5, max: o.life || 0.5, col: o.col || "rgba(10,10,16,.25)", sz: (o.sz || 0.06) * (0.6 + Math.random() * 0.8) });
    }
  }
  function addShake(v) { shake = Math.max(shake, v); }
  function hit(i, why) { anim.hit = { i: i, t: 0, why: why }; }

  /* ---------------- one frame ----------------
     V: { st, sub (fraction of a tick), t (seconds, wall clock), dt, home, dead, won, noShake } */
  function frame(V) {
    const c = g, st = V.st, dt = V.dt, t = V.t, ts = view.ts;
    c.setTransform(dpr, 0, 0, dpr, 0, 0);
    c.fillStyle = COL.bg; c.fillRect(0, 0, W, H);
    if (!L || !st) return;
    shake = Math.max(0, shake - dt * 3.2);
    const sk = V.noShake || RM ? 0 : shake * ts * 0.22, sx = (Math.random() - 0.5) * sk, sy = (Math.random() - 0.5) * sk;
    c.save();
    c.translate(view.ox + sx, view.oy + sy);
    if (view.rot) { c.translate(L.h * ts, 0); c.rotate(Math.PI / 2); }
    c.drawImage(layer, -layer.m, -layer.m, layer.width / dpr, layer.height / dpr);
    c.scale(ts, ts);
    const sec = (st.t + (V.sub || 0)) / HZ;
    /* under the trail: conveyors, plates, unbroken cracks */
    for (const cv0 of L.convs) drawConv(c, cv0, t);
    for (const pl of L.plates) drawPlate(c, pl, !!st.trail[pl.i] || plateLocal(st, pl.i));
    for (let i = 0; i < L.N; i++) if (L.k[i] === K.CRACK && st.trail[i] !== 2) drawCrack(c, i, false);
    /* the trail */
    const rp = SIM.ratPos(L, st, V.sub || 0);
    drawTrail(c, st, rp, V.sub || 0);
    /* over the trail */
    for (let i = 0; i < L.N; i++) {
      const kk = L.k[i];
      if (kk === K.PUDDLE) drawPuddle(c, i, t);
      else if (kk === K.CRACK && st.trail[i] === 2) drawCrack(c, i, true);
      else if (kk === K.TRAP) drawTrap(c, i, anim.snap === i);
      else if (kk === K.GLUE) { c.save(); c.globalAlpha = 0.5; c.scale(1 / ts, 1 / ts); drawGlue(c, i % L.w, i / L.w | 0, ts); c.restore(); }
    }
    L.portals.forEach(function (o, pi) { const colr = COL.ids[(pi + 1) % COL.ids.length]; drawPortal(c, o.a, colr, t); drawPortal(c, o.b, colr, t); });
    for (let gi = 0; gi < L.gates.length; gi++) {
      const target = SIM.gateOpen(L, st, gi, null) || gateLocal(st, gi) ? 1 : 0;
      anim.gates[gi] += (target - anim.gates[gi]) * Math.min(1, dt * 7);
      drawGate(c, L.gates[gi], anim.gates[gi]);
    }
    for (let di = 0; di < L.doors.length; di++) drawDoor(c, di, SIM.doorState(L, di, sec));
    drawCheese(c, L.cheese, t, V.won ? V.wonT : 0);
    for (const ls of L.lasers) { const ph = SIM.laserPhase(ls, sec); drawBeam(c, ls, ph, t); drawEmitter(c, ls, ph, t); }
    for (const pw of L.paws) drawPaw(c, pw, SIM.pawPhase(pw, sec));
    for (let fi = 0; fi < L.fans.length; fi++) {
      const goal = st.fan[fi] * Math.PI / 2; let cur = anim.fans[fi];
      let d = goal - cur; while (d > Math.PI) d -= Math.PI * 2; while (d < -Math.PI) d += Math.PI * 2;
      anim.fans[fi] = cur + d * Math.min(1, dt * 14); drawFan(c, fi, t);
    }
    for (const r of L.robots) { const p = SIM.robotPos(r, sec); drawRobot(c, p[0], p[1], p[2], t, false); }
    for (const s of L.snakes) drawSnake(c, SIM.snakeSegs(s, sec), t);
    if (st.ch) { const p = SIM.chaserPos(L, st, V.sub || 0), a = Math.atan2(rp[1] - p[1], rp[0] - p[0]); drawRobot(c, p[0], p[1], a, t, true); }
    /* the rat */
    const dir = SIM.ratDir(L, st, V.sub || 0), goalA = [Math.PI, -Math.PI / 2, 0, Math.PI / 2][dir];
    let da = goalA - anim.ang; while (da > Math.PI) da -= Math.PI * 2; while (da < -Math.PI) da += Math.PI * 2;
    anim.ang += da * Math.min(1, dt * 22);
    const rx = rp[0] + 0.5, ry = rp[1] + 0.5, moving = !!st.sl && st.sl.n > 0;
    let bx = 0, by = 0;
    if (V.bump && !RM) { const b = V.bump, k = Math.max(0, 1 - b.t / 0.16); bx = DX[b.d] * 0.12 * Math.sin(k * Math.PI); by = DY[b.d] * 0.12 * Math.sin(k * Math.PI); }
    tailStep(rx + bx, ry + by, anim.ang, dt, t, moving);
    if (rp[2] > 0.05) { drawTail(c); drawRat(c, rx + bx, ry + by, anim.ang, rp[2], V.squash || 0); }
    /* the hit: a red ring where the rat ran into its trail or a hazard */
    if (anim.hit) {
      anim.hit.t += dt;
      const p = anim.hit.i >= 0 ? cxy(anim.hit.i) : [rx, ry], k = anim.hit.t;
      if (k < 1.2) { c.strokeStyle = "rgba(190,0,54," + Math.max(0, 1 - k) + ")"; c.lineWidth = 0.08; c.beginPath(); c.arc(p[0], p[1], 0.3 + k * 0.6, 0, Math.PI * 2); c.stroke();
        c.strokeStyle = "rgba(190,0,54,.9)"; c.lineWidth = 0.1; c.lineCap = "round"; c.beginPath(); c.moveTo(p[0] - 0.18, p[1] - 0.18); c.lineTo(p[0] + 0.18, p[1] + 0.18); c.moveTo(p[0] + 0.18, p[1] - 0.18); c.lineTo(p[0] - 0.18, p[1] + 0.18); c.stroke(); }
    }
    /* particles */
    for (let i = parts.length - 1; i >= 0; i--) {
      const q = parts[i]; q.life -= dt; if (q.life <= 0) { parts.splice(i, 1); continue; }
      q.x += q.vx * dt; q.y += q.vy * dt; q.vx *= 1 - dt * 3; q.vy *= 1 - dt * 3;
      c.globalAlpha = Math.min(1, q.life / q.max * 1.5); c.fillStyle = q.col; c.beginPath(); c.arc(q.x, q.y, q.sz, 0, Math.PI * 2); c.fill();
    }
    c.globalAlpha = 1;
    c.restore();
    if (V.home) { c.fillStyle = "rgba(237,239,242,.62)"; c.fillRect(0, 0, W, H); }
  }
  function plateLocal(st, i) { const p = st.sl; if (!p) return false; for (let k = 1; k <= p.k; k++) if (p.pts[k] === i) return true; return false; }
  function gateLocal(st, gi) { for (const pi of L.gates[gi].plates) if (plateLocal(st, pi)) return true; return false; }
  function drawTrail(c, st, rp, sub) {
    const vis = st.vis; if (!vis || !vis.length) return;
    const lines = []; let cur = [];
    for (const i of vis) { if (i < 0) { if (cur.length) lines.push(cur); cur = []; continue; } cur.push(cxy(i)); }
    /* the live end follows the rat, not the tile it is entering */
    const p = st.sl;
    if (p && p.n > 0) {
      const s = p.n * SIM.ease((st.t + sub - p.t0) / p.T);
      if (s < p.k && cur.length > 1 && !p.tp[p.k]) cur.pop();
      if (rp[2] > 0.5 || !p.tp[Math.min(p.n, Math.floor(s) + 1)]) cur.push([rp[0] + 0.5, rp[1] + 0.5]);
    }
    lines.push(cur);
    c.save(); c.lineCap = "round"; c.lineJoin = "round";
    for (const pass of [[0.5, COL.trailEdge], [0.42, COL.trail]]) {
      c.strokeStyle = pass[1]; c.lineWidth = pass[0];
      for (const ln of lines) {
        if (!ln.length) continue;
        c.beginPath(); c.moveTo(ln[0][0], ln[0][1]);
        if (ln.length === 1) c.lineTo(ln[0][0] + 0.001, ln[0][1]);
        for (let k = 1; k < ln.length; k++) c.lineTo(ln[k][0], ln[k][1]);
        c.stroke();
      }
    }
    c.restore();
  }

  root.RENDER = { init: init, resize: resize, setInsets: setInsets, setLevel: setLevel, frame: frame, toGrid: toGrid, emit: emit,
    shake: addShake, hit: hit, mazeRect: mazeRect, worldToScreen: worldToScreen, view: view, anim: anim, COL: COL,
    setQuality: function (q) { quality = q; resize(); }, snapTrap: function (i) { anim.snap = i; },
    get level() { return L; } };
})(this);
