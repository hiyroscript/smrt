/* ---- sim.js ----
   SIM: the whole game rule set as pure, deterministic logic on a fixed 60 Hz tick. The game, the home demo, the
   solver and the Node tools all step the same code, so a solution the tools verify plays out identically on screen.

   Grid: 0 void (outside the maze shape), 1 wall, 2 floor. Special tiles sit on floor (or, for the fan, on a wall).
   Directions: 0 up, 1 right, 2 down, 3 left.

   A move: the rat slides in a direction until something stops it (a wall, a glue pad, a closed door or gate, a fan
   it can't turn on), with one eased tween over the whole slide. The slide is planned the moment it starts (every
   obstacle's timing is a pure function of the level clock, so the plan is exact) and then played tick by tick,
   painting the trail, breaking cracks and pressing plates as the rat reaches each tile. Moving hazards are checked
   every tick against the rat's actual position, while sliding and while idle. */
(function (root) {
  "use strict";
  const HZ = 60, DT = 1 / HZ, LIMIT = 60 * HZ;
  const DX = [0, 1, 0, -1], DY = [-1, 0, 1, 0];
  const SPEED = 20;                  /* average slide speed, tiles per second */
  const MIN_T = 6, MAX_T = 45;       /* slide duration clamp in ticks: 0.1 s (short slides stay snappy) .. 0.75 s */
  const BUMP_T = 5;                  /* a move that goes nowhere but does something (turning a fan, hitting the trail) */
  const EASE_A = 0.6;                /* 0 = linear, 1 = full ease-out */
  const K = { NONE: 0, TRAP: 1, GLUE: 2, PUDDLE: 3, CRACK: 4, CONV: 5, PORTAL: 6, DOOR: 7, PLATE: 8, GATE: 9, FAN: 10 };
  const HIT = { robot: 0.72, snake: 0.66, chaser: 0.7 };   /* contact distances in tiles */
  const PAW = { strike: 0.45, warn: 0.65 };                /* seconds */
  const LASER_WARN = 0.45;
  const CHASER_T = 12;                                     /* ticks a chaser takes to move one tile */

  function ease(u) { u = u < 0 ? 0 : u > 1 ? 1 : u; return u * (1 - EASE_A) + EASE_A * (1 - (1 - u) * (1 - u)); }
  function easeInv(s) { let a = 0, b = 1; for (let i = 0; i < 26; i++) { const m = (a + b) / 2; if (ease(m) < s) a = m; else b = m; } return (a + b) / 2; }
  function slideTicks(n) { return n <= 0 ? BUMP_T : Math.max(MIN_T, Math.min(MAX_T, Math.round((0.04 + n / SPEED) * HZ))); }
  const mod = function (a, b) { return ((a % b) + b) % b; };

  /* ---------------- compile a level definition ---------------- */
  function polyline(pts, closed) {
    const P = pts.map(function (p) { return [p[0], p[1]]; });
    if (closed) P.push([P[0][0], P[0][1]]);
    const cum = [0];
    for (let i = 1; i < P.length; i++) cum.push(cum[i - 1] + Math.abs(P[i][0] - P[i - 1][0]) + Math.abs(P[i][1] - P[i - 1][1]));
    return { P: P, cum: cum, len: cum[cum.length - 1] };
  }
  function along(pl, d) {   /* point and heading at arc length d on a polyline */
    const P = pl.P, cum = pl.cum;
    let i = 1; while (i < P.length - 1 && cum[i] < d) i++;
    const seg = cum[i] - cum[i - 1] || 1, f = Math.max(0, Math.min(1, (d - cum[i - 1]) / seg));
    const a = P[i - 1], b = P[i];
    return [a[0] + (b[0] - a[0]) * f, a[1] + (b[1] - a[1]) * f, Math.atan2(b[1] - a[1], b[0] - a[0])];
  }
  function xorshift(seed) { let s = seed >>> 0 || 1; return function () { s ^= s << 13; s >>>= 0; s ^= s >>> 17; s ^= s << 5; s >>>= 0; return s; }; }

  function compile(def) {
    const w = def.w, h = def.h, N = w * h;
    const g = new Uint8Array(N), k = new Uint8Array(N), kv = new Int16Array(N).fill(-1);
    for (let y = 0; y < h; y++) for (let x = 0; x < w; x++) { const c = def.rows[y][x]; g[y * w + x] = c === "#" ? 1 : c === "." ? 2 : 0; }
    const L = { def: def, n: def.n, w: w, h: h, N: N, g: g, k: k, kv: kv,
      start: def.start[1] * w + def.start[0], cheese: def.cheese[1] * w + def.cheese[0],
      portals: [], doors: [], fans: [], plates: [], gates: [], lasers: [], paws: [], robots: [], snakes: [], chaser: null, convs: [] };
    const at = function (x, y) { return y * w + x; };
    for (const o of def.obs || []) {
      switch (o.k) {
        case "trap": k[at(o.x, o.y)] = K.TRAP; break;
        case "glue": k[at(o.x, o.y)] = K.GLUE; break;
        case "puddle": k[at(o.x, o.y)] = K.PUDDLE; break;
        case "crack": k[at(o.x, o.y)] = K.CRACK; break;
        case "conv": { const i = at(o.x, o.y); k[i] = K.CONV; kv[i] = o.d; L.convs.push({ i: i, d: o.d }); break; }
        case "portal": { const a = at(o.a[0], o.a[1]), b = at(o.b[0], o.b[1]); k[a] = k[b] = K.PORTAL; kv[a] = kv[b] = L.portals.length; L.portals.push({ a: a, b: b }); break; }
        case "door": { const i = at(o.x, o.y); k[i] = K.DOOR; kv[i] = L.doors.length; L.doors.push({ i: i, p: o.p, o: o.o, ph: o.ph, ax: o.ax }); break; }
        case "plate": { const i = at(o.x, o.y); k[i] = K.PLATE; kv[i] = o.id; L.plates.push({ i: i, id: o.id }); break; }
        case "gate": { const i = at(o.x, o.y); k[i] = K.GATE; kv[i] = L.gates.length; L.gates.push({ i: i, id: o.id, ax: o.ax, plates: [] }); break; }
        case "fan": { const i = at(o.x, o.y); k[i] = K.FAN; kv[i] = L.fans.length; L.fans.push({ i: i, d: o.d }); break; }
        case "laser": L.lasers.push({ e: at(o.x, o.y), d: o.d, on: o.on, off: o.off, ph: o.ph, cells: [] }); break;
        case "paw": L.paws.push({ i: at(o.x, o.y), from: o.from, p: o.p, ph: o.ph }); break;
        case "robot": L.robots.push({ pl: polyline(o.path, false), v: o.v, ph: o.ph }); break;
        case "snake": L.snakes.push({ pl: polyline(o.path, true), v: o.v, ph: o.ph, len: o.len, gap: 0.8 }); break;
        case "chaser": L.chaser = { i: at(o.x, o.y) }; break;
      }
    }
    for (const gt of L.gates) for (const p of L.plates) if (p.id === gt.id) gt.plates.push(p.i);
    for (const ls of L.lasers) {   /* the beam runs over floor from the emitter until something solid */
      let x = ls.e % w + DX[ls.d], y = (ls.e / w | 0) + DY[ls.d];
      while (x >= 0 && y >= 0 && x < w && y < h && g[at(x, y)] === 2) { ls.cells.push(at(x, y)); x += DX[ls.d]; y += DY[ls.d]; }
      ls.set = new Set(ls.cells);
    }
    const r1 = xorshift(0x9E3779B9 ^ (def.n * 7919)), r2 = xorshift(0x85EBCA6B ^ (def.n * 104729));
    L.z1 = new Uint32Array(N); L.z2 = new Uint32Array(N);
    for (let i = 0; i < N; i++) { L.z1[i] = r1(); L.z2[i] = r2(); }
    L.timed = !!(L.robots.length || L.snakes.length || L.paws.length || L.lasers.length || L.doors.length);
    L.floor = 0; for (let i = 0; i < N; i++) if (g[i] === 2) L.floor++;
    return L;
  }

  /* ---------------- timed obstacles: pure functions of the clock (seconds) ---------------- */
  function doorOpen(L, di, sec) { const d = L.doors[di]; return mod(sec + d.ph, d.p) < d.o; }
  function doorState(L, di, sec) {   /* 0 closed .. 1 open, with a short swing between, for drawing */
    const d = L.doors[di], tau = mod(sec + d.ph, d.p), sw = 0.18;
    if (tau < d.o) return tau < sw ? tau / sw : 1;
    return tau - d.o < sw ? 1 - (tau - d.o) / sw : 0;
  }
  function laserPhase(ls, sec) {   /* 2 on, 1 warming up, 0 off */
    const tau = mod(sec + ls.ph, ls.on + ls.off);
    return tau < ls.on ? 2 : tau >= ls.on + ls.off - LASER_WARN ? 1 : 0;
  }
  function pawPhase(pw, sec) {     /* [phase, 0..1 within it]: 2 strike, 1 warning shadow, 0 hidden */
    const tau = mod(sec + pw.ph, pw.p);
    if (tau >= pw.p - PAW.strike) return [2, (tau - (pw.p - PAW.strike)) / PAW.strike];
    if (tau >= pw.p - PAW.strike - PAW.warn) return [1, (tau - (pw.p - PAW.strike - PAW.warn)) / PAW.warn];
    return [0, 0];
  }
  function robotPos(r, sec) {
    const Lr = r.pl.len; let d = mod(r.v * sec + r.ph * Lr * 2, 2 * Lr), back = false;
    if (d > Lr) { d = 2 * Lr - d; back = true; }
    const p = along(r.pl, d); if (back) p[2] += Math.PI;
    return p;
  }
  function snakeSegs(s, sec) {
    const out = [], Ls = s.pl.len, head = mod(s.v * sec + s.ph * Ls, Ls);
    for (let i = 0; i < s.len; i++) out.push(along(s.pl, mod(head - i * s.gap, Ls)));
    return out;
  }

  /* ---------------- state ---------------- */
  function newState(L, lite) {
    const st = { t: 0, x: L.start % L.w, y: L.start / L.w | 0, d: 2, trail: new Uint8Array(L.N), h1: 0, h2: 0,
      fan: new Int8Array(L.fans.length), ch: null, sl: null, out: null, hit: -1, moves: 0, vis: lite ? null : [L.start], ev: lite ? null : [] };
    for (let i = 0; i < L.fans.length; i++) st.fan[i] = L.fans[i].d;
    if (L.chaser) st.ch = { i: L.chaser.i, p: L.chaser.i, mt: -999 };
    paint(L, st, L.start);
    return st;
  }
  function clone(st, keepVis) {
    return { t: st.t, x: st.x, y: st.y, d: st.d, trail: st.trail.slice(), h1: st.h1, h2: st.h2, fan: st.fan.slice(),
      ch: st.ch ? { i: st.ch.i, p: st.ch.p, mt: st.ch.mt } : null, sl: st.sl ? Object.assign({}, st.sl) : null,
      out: st.out, hit: st.hit, moves: st.moves, vis: keepVis && st.vis ? st.vis.slice() : null, ev: null };
  }
  function paintable(L, i) { const k = L.k[i]; return k !== K.PUDDLE && k !== K.PORTAL; }
  function paint(L, st, i) {
    if (!paintable(L, i) || st.trail[i]) return;
    st.trail[i] = 1; st.h1 ^= L.z1[i]; st.h2 ^= L.z2[i];
  }
  function emit(st, e) { if (st.ev) st.ev.push(e); }
  function gateOpen(L, st, gi, local) {
    for (const p of L.gates[gi].plates) if (st.trail[p] || (local && local.has(p))) return true;
    return false;
  }

  /* ---------------- planning a slide ---------------- */
  function plan(L, st, d0) {
    const w = L.w, pts = [st.y * w + st.x], tp = [false], fev = [], fanL = Array.from(st.fan), local = new Set(), doorsK = [];
    let x = st.x, y = st.y, d = d0, out = null, hit = -1, turns = 0, teles = 0;
    for (let guard = 0; guard < 600; guard++) {
      const nx = x + DX[d], ny = y + DY[d];
      if (nx < 0 || ny < 0 || nx >= w || ny >= L.h) break;
      const ni = ny * w + nx, kk = L.k[ni];
      if (kk === K.FAN) {   /* hit a fan block: it turns the rat 90° if its arrow allows, and rotates a quarter either way */
        const fi = L.kv[ni], a = fanL[fi];
        fanL[fi] = (a + 1) & 3;
        fev.push({ k: pts.length - 1, f: fi, a: fanL[fi] });
        if ((a & 1) !== (d & 1) && turns++ < 8) { d = a; continue; }
        break;
      }
      if (L.g[ni] !== 2) break;
      if (kk === K.GATE && !gateOpen(L, st, L.kv[ni], local)) break;
      if (kk === K.CRACK && (st.trail[ni] || local.has(ni))) break;   /* a cracked tile once left is a hole: solid */
      if (st.trail[ni] || local.has(ni)) { out = "trail"; hit = ni; break; }
      if (kk === K.DOOR) doorsK.push(pts.length);
      x = nx; y = ny; pts.push(ni); tp.push(false);
      if (paintable(L, ni)) local.add(ni);
      if (kk === K.TRAP) { out = "trap"; break; }
      if (ni === L.cheese) { out = "win"; break; }
      if (kk === K.GLUE) break;
      if (kk === K.CONV) { d = L.kv[ni]; continue; }
      if (kk === K.PORTAL) {
        if (teles++ >= 4) break;
        const o = L.portals[L.kv[ni]], j = o.a === ni ? o.b : o.a;
        x = j % w; y = j / w | 0; pts.push(j); tp.push(true);
        continue;
      }
    }
    /* doors: each is checked at the moment the eased slide would reach it; a closed one ends the slide just before it
       (which changes the slide's length and so its timing, hence the loop) */
    let n = pts.length - 1;
    for (let again = true; again && doorsK.length;) {
      again = false;
      const T = slideTicks(n);
      for (const kq of doorsK) {
        if (kq > n) break;
        const tk = st.t + T * easeInv((kq - 0.5) / n);
        if (!doorOpen(L, L.kv[pts[kq]], tk / HZ)) { n = kq - 1; out = null; hit = -1; again = true; break; }
      }
    }
    pts.length = n + 1; tp.length = n + 1;
    return { pts: pts, tp: tp, fev: fev.filter(function (e) { return e.k <= n; }), n: n, out: out, hit: hit, d: d0, T: slideTicks(n), t0: st.t, k: 0, fi: 0 };
  }

  /* ---------------- moving ---------------- */
  /* returns "move", "bump" (blocked at once: nothing happens), "busy" (sliding) or "over" */
  function move(L, st, d) {
    if (st.out) return "over";
    if (st.sl) return "busy";
    const p = plan(L, st, d);
    if (p.n === 0 && !p.out && !p.fev.length) { emit(st, { e: "bump", d: d }); return "bump"; }
    st.d = d; st.sl = p;
    applyFans(L, st, p, 0);
    return "move";
  }
  function applyFans(L, st, p, upto) {
    while (p.fi < p.fev.length && p.fev[p.fi].k <= upto) {
      const e = p.fev[p.fi++]; st.fan[e.f] = e.a; emit(st, { e: "fan", f: e.f });
    }
  }
  function enter(L, st, p, kq) {
    const i = p.pts[kq], prev = p.pts[kq - 1];
    if (st.vis) { if (p.tp[kq]) st.vis.push(-1); st.vis.push(i); }
    if (p.tp[kq]) emit(st, { e: "portal", a: prev, b: i });
    if (L.k[prev] === K.CRACK && st.trail[prev] === 1) { st.trail[prev] = 2; emit(st, { e: "crack", i: prev }); }
    paint(L, st, i);
    const kk = L.k[i];
    if (kk === K.PLATE) emit(st, { e: "plate", i: i });
    else if (kk === K.PUDDLE) emit(st, { e: "splash", i: i });
    else if (kk === K.CONV) emit(st, { e: "conv", i: i });
  }
  function step(L, st) {
    if (st.out) return;
    st.t++;
    const p = st.sl;
    if (p) {
      const u = (st.t - p.t0) / p.T, s = p.n * ease(u);
      while (p.k < p.n && s >= p.k + 0.5) { p.k++; enter(L, st, p, p.k); applyFans(L, st, p, p.k); }
      if (u >= 1) finish(L, st, p);
    }
    if (!st.out) hazards(L, st);
    if (!st.out && st.t >= LIMIT) { st.out = "time"; emit(st, { e: "die", why: "time" }); }
  }
  function finish(L, st, p) {
    while (p.k < p.n) { p.k++; enter(L, st, p, p.k); }
    applyFans(L, st, p, 1e9);
    const last = p.pts[p.n];
    st.x = last % L.w; st.y = last / L.w | 0; st.sl = null; st.moves++;
    if (p.out) {
      st.out = p.out; st.hit = p.hit;
      emit(st, p.out === "win" ? { e: "win" } : { e: "die", why: p.out, hit: p.hit });
      return;
    }
    emit(st, { e: "stop", n: p.n, d: p.d, glue: L.k[last] === K.GLUE });
    if (st.ch) chaserStep(L, st);
    if (!st.out && stuck(L, st)) { st.out = "stuck"; emit(st, { e: "die", why: "stuck" }); }
  }
  /* no way out: every side is solid for good, or the trail (doors and fans could still change, so they don't count) */
  function stuck(L, st) {
    for (let d = 0; d < 4; d++) {
      const nx = st.x + DX[d], ny = st.y + DY[d];
      if (nx < 0 || ny < 0 || nx >= L.w || ny >= L.h) continue;
      const i = ny * L.w + nx, kk = L.k[i];
      if (kk === K.FAN || kk === K.DOOR) return false;
      if (L.g[i] !== 2) continue;
      if (kk === K.GATE && !gateOpen(L, st, L.kv[i], null)) continue;
      if (st.trail[i]) continue;
      return false;
    }
    return true;
  }

  /* ---------------- where things are ---------------- */
  /* the rat's centre in tile units; sub: a fraction of a tick, for smooth drawing */
  function ratPos(L, st, sub) {
    const p = st.sl, w = L.w;
    if (!p) return [st.x, st.y, 1];
    const s = p.n * ease((st.t + (sub || 0) - p.t0) / p.T);
    const kq = Math.min(p.n, Math.floor(s));
    if (kq >= p.n) { const i = p.pts[p.n]; return [i % w, i / w | 0, 1]; }
    const f = s - kq, a = p.pts[kq], b = p.pts[kq + 1];
    if (p.tp[kq + 1]) {   /* through a portal: shrink into one hole, grow out of the other */
      const i = f < 0.5 ? a : b; return [i % w, i / w | 0, Math.abs(f - 0.5) * 2];
    }
    const ax = a % w, ay = a / w | 0, bx = b % w, by = b / w | 0;
    return [ax + (bx - ax) * f, ay + (by - ay) * f, 1];
  }
  function ratDir(L, st, sub) {   /* the direction the rat is travelling (or last travelled) */
    const p = st.sl, w = L.w;
    if (!p || p.n === 0) return st.d;
    const s = p.n * ease((st.t + (sub || 0) - p.t0) / p.T);
    let kq = Math.min(p.n - 1, Math.floor(s));
    while (kq > 0 && p.tp[kq + 1]) kq--;
    let a = p.pts[kq], b = p.pts[kq + 1];
    if (p.tp[kq + 1]) return st.d;
    const dx = b % w - a % w, dy = (b / w | 0) - (a / w | 0);
    return dy < 0 ? 0 : dx > 0 ? 1 : dy > 0 ? 2 : 3;
  }
  function chaserPos(L, st, sub) {
    const c = st.ch; if (!c) return null;
    const f = Math.max(0, Math.min(1, (st.t + (sub || 0) - c.mt) / CHASER_T)), w = L.w;
    const ax = c.p % w, ay = c.p / w | 0, bx = c.i % w, by = c.i / w | 0;
    return [ax + (bx - ax) * f, ay + (by - ay) * f];
  }
  function walkable(L, st, i) {   /* where the chaser can roll: floor, trail included, except traps, holes and closed gates */
    if (L.g[i] !== 2) return false;
    const kk = L.k[i];
    if (kk === K.TRAP) return false;
    if (kk === K.CRACK && st.trail[i] === 2) return false;
    if (kk === K.GATE && !gateOpen(L, st, L.kv[i], null)) return false;
    return true;
  }
  function chaserStep(L, st) {
    const c = st.ch, w = L.w, N = L.N, target = st.y * w + st.x;
    const dist = new Int16Array(N).fill(-1), q = [target]; dist[target] = 0;
    for (let qi = 0; qi < q.length; qi++) {
      const i = q[qi], x = i % w, y = i / w | 0;
      for (let d = 0; d < 4; d++) {
        const nx = x + DX[d], ny = y + DY[d]; if (nx < 0 || ny < 0 || nx >= w || ny >= L.h) continue;
        const j = ny * w + nx; if (dist[j] >= 0 || !walkable(L, st, j)) continue;
        dist[j] = dist[i] + 1; q.push(j);
      }
    }
    const here = dist[c.i]; if (here <= 0) return;
    const x = c.i % w, y = c.i / w | 0;
    for (let d = 0; d < 4; d++) {
      const nx = x + DX[d], ny = y + DY[d]; if (nx < 0 || ny < 0 || nx >= w || ny >= L.h) continue;
      const j = ny * w + nx;
      if (dist[j] === here - 1) { c.p = c.i; c.i = j; c.mt = st.t; emit(st, { e: "chase" }); return; }
    }
  }
  function hazards(L, st) {
    if (!L.timed && !st.ch) return;
    const sec = st.t / HZ, rp = ratPos(L, st, 0), rx = rp[0], ry = rp[1];
    const ti = Math.round(ry) * L.w + Math.round(rx);
    let why = null;
    for (const r of L.robots) { const p = robotPos(r, sec), dx = p[0] - rx, dy = p[1] - ry; if (dx * dx + dy * dy < HIT.robot * HIT.robot) { why = "robot"; break; } }
    if (!why) for (const s of L.snakes) { for (const p of snakeSegs(s, sec)) { const dx = p[0] - rx, dy = p[1] - ry; if (dx * dx + dy * dy < HIT.snake * HIT.snake) { why = "snake"; break; } } if (why) break; }
    if (!why) for (const pw of L.paws) if (pw.i === ti && pawPhase(pw, sec)[0] === 2) { why = "paw"; break; }
    if (!why) for (const ls of L.lasers) if (ls.set.has(ti) && laserPhase(ls, sec) === 2) { why = "laser"; break; }
    if (!why && st.ch) { const p = chaserPos(L, st, 0), dx = p[0] - rx, dy = p[1] - ry; if (dx * dx + dy * dy < HIT.chaser * HIT.chaser) why = "chaser"; }
    if (why) { st.out = why; emit(st, { e: "die", why: why }); }
  }

  /* ---------------- replay a solution: [[waitTicks, dir], ...] ---------------- */
  function replay(L, moves, st) {
    st = st || newState(L, true);
    for (const m of moves) {
      for (let i = 0; i < m[0] && !st.out; i++) step(L, st);
      if (st.out) break;
      if (move(L, st, m[1]) !== "move") { st.out = st.out || "bad"; break; }
      while (st.sl && !st.out) step(L, st);
      if (st.out) break;
    }
    return st;
  }

  const SIM = { HZ: HZ, DT: DT, LIMIT: LIMIT, DX: DX, DY: DY, K: K, PAW: PAW, CHASER_T: CHASER_T,
    ease: ease, slideTicks: slideTicks, compile: compile, newState: newState, clone: clone, plan: plan, move: move, step: step,
    ratPos: ratPos, ratDir: ratDir, chaserPos: chaserPos, robotPos: robotPos, snakeSegs: snakeSegs, pawPhase: pawPhase,
    laserPhase: laserPhase, doorOpen: doorOpen, doorState: doorState, gateOpen: gateOpen, replay: replay, mod: mod };
  if (typeof module !== "undefined" && module.exports) module.exports = SIM; else root.SIM = SIM;
})(this);
