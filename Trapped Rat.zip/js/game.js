/* ---- game.js ----
   Screens, input, HUD, cards, saving and cheese ratings. UI behaviour follows hiyroscript/shkr (screens, cards with
   arming, the wipe from the start orb, pause rules); the game itself is SIM (rules), RENDER (drawing) and DEMO (the
   home screen's background). */
(function () {
  "use strict";
  const $ = function (s, r) { return (r || document).querySelector(s); };
  const $$ = function (s, r) { return Array.prototype.slice.call((r || document).querySelectorAll(s)); };
  const pad2 = function (n) { return (n < 10 ? "0" : "") + n; };
  const now = function () { return performance.now() / 1000; };
  const esc = function (v) { return String(v).replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;"); };
  const HZ = SIM.HZ, LIMIT = SIM.LIMIT, N = LEVELS.length;
  const RM = !!(window.matchMedia && window.matchMedia("(prefers-reduced-motion: reduce)").matches);

  /* ---------------- cheese ratings ----------------
     By the time left on the 60 s clock when the rat reaches the cheese: more than `left` seconds earns `v`.
     v 4 = three rainbow cheeses. Running out of time fails the level (0). */
  const RATING = [
    { left: 45, v: 4 },   /* finished in under 15 s */
    { left: 30, v: 3 },
    { left: 25, v: 2 },
    { left: 0, v: 1 }
  ];
  function cheeseFor(left) { for (const r of RATING) if (left > r.left) return r.v; return 1; }
  function cheeseHTML(v, cls) {
    let h = '<div class="stars' + (cls ? " " + cls : "") + '">';
    for (let i = 0; i < 3; i++) h += '<i class="cheese' + (v === 4 ? " rb" : i < v ? " on" : "") + '"></i>';
    return h + "</div>";
  }

  /* ---------------- saved state ----------------
     one localStorage key; per level { d: done, s: best cheese 0–4, t: tries, b: best time (s) }, plus unlocked */
  const KEY = "trappedrat.v1";
  const DEFAULTS = { shake: true, sel: 1, unlocked: 1, rec: {} };
  let S = loadState();
  function loadState() {
    let raw = {};
    try { raw = JSON.parse(localStorage.getItem(KEY) || "{}") || {}; } catch (e) { raw = {}; }
    return checkState(raw);
  }
  function checkState(raw) {
    const o = {};
    for (const k in DEFAULTS) o[k] = raw[k] !== undefined && raw[k] !== null ? raw[k] : JSON.parse(JSON.stringify(DEFAULTS[k]));
    o.unlocked = Math.max(1, Math.min(N, o.unlocked | 0 || 1)); o.sel = Math.max(1, Math.min(N, o.sel | 0 || 1));
    if (typeof o.rec !== "object" || !o.rec) o.rec = {};
    o.shake = o.shake !== false;
    return o;
  }
  function saveState() { try { localStorage.setItem(KEY, JSON.stringify(S)); } catch (e) {} }
  function rec(n) { return S.rec[n] || (S.rec[n] = { d: false, s: 0, t: 0, b: 0 }); }
  const clockText = function (sec, tenths) {
    sec = Math.max(0, sec);
    if (tenths) { const m = Math.floor(sec / 60), s = sec - m * 60; return m + ":" + (s < 10 ? "0" : "") + s.toFixed(1); }
    const c = Math.ceil(sec - 1e-6), m = Math.floor(c / 60), s = c - m * 60; return m + ":" + pad2(s);
  };

  /* ---------------- levels ---------------- */
  const cache = {};
  function getL(n) { return cache[n] || (cache[n] = SIM.compile(LEVELS[n - 1])); }

  const G = { mode: "home", paused: false, n: 1, L: null, st: null, acc: 0, deadAt: 0, wonAt: 0, cardUp: false, bump: null, squash: 0, timer: 0 };

  /* ---------------- screens ---------------- */
  const SCREENS = ["home", "settings", "levels"], PANELS = ["settings", "levels"];
  function show(id) {
    SCREENS.forEach(function (s) { const el = document.getElementById(s); el.classList.toggle("on", s === id); el.classList.remove("enter"); });
    const el = document.getElementById(id);
    if (el) { void el.offsetWidth; el.classList.add("enter"); }
    if (id === "levels") paintLevels();
    if (id === "home") paintHome(true);
    if (id === "settings") paintSettings();
    DEMO.pause(id !== "home");
  }
  function panelOn() { for (const id of PANELS) if (document.getElementById(id).classList.contains("on")) return id; return ""; }
  $$("[data-go]").forEach(function (b) { b.addEventListener("click", function () { show(b.dataset.go); }); });

  /* ---------------- cards ---------------- */
  const overlay = $("#overlay"), cardEl = $("#card");
  let cardActs = [], cardFade = 0;
  /* a card's buttons take a press only once it has been up CARD_ARM s, and only a press that started then: a swipe
     that ends as a fail or win card comes up never lands on one of its buttons */
  const CARD_ARM = 0.45;
  let cardAt = -1e9, cardDown = -1e9, armT = 0;
  function showCard(o) {
    clearTimeout(cardFade);
    if (overlay.classList.contains("out")) clearCard();
    let html = "";
    if (o.eyebrow) html += '<div class="eyebrow">' + o.eyebrow + "</div>";
    if (o.title) html += "<h2>" + o.title + "</h2>";
    if (o.stars !== undefined) html += cheeseHTML(o.stars, "big");
    if (o.body) html += "<p>" + o.body + "</p>";
    if (o.stats) { html += '<div class="stat-row">'; o.stats.forEach(function (s) { html += "<div><b" + (s[2] ? ' class="new"' : "") + ">" + s[0] + "</b><span>" + s[1] + "</span></div>"; }); html += "</div>"; }
    html += '<div class="acts">';
    (o.acts || []).forEach(function (a, i) { html += '<button class="chip' + (a.solid ? " solid" : "") + (a.danger ? " danger" : "") + '" data-act="' + i + '">' + a.t + "</button>"; });
    html += "</div>";
    cardEl.innerHTML = html; cardEl.className = "card arming" + (o.cls ? " " + o.cls : ""); cardActs = o.acts || []; overlay.classList.add("on"); G.cardUp = true;
    cardAt = now(); clearTimeout(armT); armT = setTimeout(function () { cardEl.classList.remove("arming"); }, CARD_ARM * 1000);
    cardEl.style.animation = "none"; void cardEl.offsetWidth; cardEl.style.animation = "";
    if (o.stars !== undefined) $$(".stars.big .cheese", cardEl).forEach(function (el, i) { setTimeout(function () { el.classList.add("pop"); }, 260 + i * 280); });
  }
  function hideCard(fade) {
    cardActs = []; G.cardUp = false; clearTimeout(cardFade);
    if (fade === true && overlay.classList.contains("on")) { overlay.classList.add("out"); cardFade = setTimeout(clearCard, 200); }
    else clearCard();
  }
  function clearCard() { overlay.classList.remove("on", "out"); cardEl.innerHTML = ""; }
  overlay.addEventListener("pointerdown", function () { cardDown = now(); }, true);
  overlay.addEventListener("click", function (e) {
    const b = e.target.closest("[data-act]"); if (!b) return;
    if (now() - cardAt < CARD_ARM || (e.detail !== 0 && cardDown < cardAt + CARD_ARM)) return;
    const a = cardActs[+b.dataset.act]; if (a && a.fn) a.fn();
  });

  /* ---------------- home ---------------- */
  function setLetters(el, text) {
    el.innerHTML = "";
    text.split(" ").forEach(function (word, wi, arr) {
      const w = document.createElement("span"); w.style.whiteSpace = "nowrap"; w.style.animation = "none";
      let i = 0;
      Array.from(word).forEach(function (ch) { const s = document.createElement("span"); s.textContent = ch; s.style.animationDelay = (wi * 0.12 + i++ * 0.03) + "s"; w.appendChild(s); });
      el.appendChild(w);
      if (wi < arr.length - 1) el.appendChild(document.createTextNode(" "));
    });
  }
  function paintHome(retitle) {
    const n = S.sel, locked = n > S.unlocked, r = S.rec[n] || { d: false, s: 0, t: 0, b: 0 };
    $("#lvTag").textContent = "level " + pad2(n) + (locked ? "  ·  locked" : "");
    if (retitle) setLetters($("#title"), LEVELS[n - 1].name);
    $("#title").style.opacity = locked ? 0.28 : 1;
    $("#homeStars").innerHTML = locked ? "" : cheeseHTML(r.d ? r.s : 0).replace(/^<div class="stars">|<\/div>$/g, "");
    $("#homeStars").style.visibility = locked ? "hidden" : "visible";
    $("#startOrb").classList.toggle("locked", locked);
    $("#startLbl").textContent = locked ? "locked" : r.d ? "replay  ·  best " + clockText(r.b, true) : r.t ? "play  ·  attempt " + (r.t + 1) : "play";
    $("#prevBtn").disabled = n <= 1; $("#nextBtn").disabled = n >= N;
    let done = 0; for (let i = 1; i <= N; i++) if (S.rec[i] && S.rec[i].d) done++;
    $("#railFill").style.width = (done / N * 100) + "%";
    $("#progTag").textContent = pad2(n) + " / " + N;
  }
  function browse(d) {
    const n = Math.max(1, Math.min(N, S.sel + d)); if (n === S.sel) return;
    S.sel = n; saveState(); paintHome(true);
  }
  $("#prevBtn").addEventListener("click", function () { browse(-1); });
  $("#nextBtn").addEventListener("click", function () { browse(1); });
  function startHome() {
    G.mode = "home"; G.paused = false; G.st = null;
    $("#hud").classList.remove("on", "danger");
    document.body.classList.add("home");
    RENDER.setInsets(0, 0, true);
    DEMO.start();
    DEMO.pause(!$("#home").classList.contains("on"));
  }
  /* the wipe: a black disc grows from (cx, cy) over the screen; fn runs under it, then it fades */
  function wipe(cx, cy, fn) {
    const w = $("#wipe"), W = window.innerWidth, H = window.innerHeight;
    const far = Math.max(Math.hypot(cx, cy), Math.hypot(W - cx, cy), Math.hypot(cx, H - cy), Math.hypot(W - cx, H - cy));
    w.style.left = (cx - 5) + "px"; w.style.top = (cy - 5) + "px"; w.style.setProperty("--sc", Math.ceil(far / 5) + "");
    w.classList.remove("go", "fade"); void w.offsetWidth; w.classList.add("go");
    setTimeout(function () {
      fn();
      w.classList.add("fade"); setTimeout(function () { w.classList.remove("go", "fade"); }, 340);
    }, RM ? 120 : 500);
  }
  function orbCentre(el) { const r = el.getBoundingClientRect(); return [r.left + r.width / 2, r.top + r.height / 2]; }
  function launch() {
    if (G.mode !== "home" || S.sel > S.unlocked) return;
    const c = orbCentre($("#startOrb"));
    G.mode = "launch";
    wipe(c[0], c[1], function () { show(""); startLevel(S.sel); });
  }
  $("#startOrb").addEventListener("click", launch);

  /* ---------------- levels panel + settings ---------------- */
  function paintLevels() {
    let html = "";
    for (let i = 1; i <= N; i++) {
      const r = S.rec[i], st = i > S.unlocked ? "locked" : i === S.sel ? "next" : r && r.d ? "done" : "";
      html += '<button class="cell ' + st + '"' + (st === "locked" ? " disabled" : "") + ' data-lv="' + i + '" aria-label="Level ' + i + '">' + pad2(i) + (i <= S.unlocked ? cheeseHTML(r && r.d ? r.s : 0) : "") + "</button>";
    }
    $("#lvGrid").innerHTML = html;
  }
  $("#lvGrid").addEventListener("click", function (e) {
    const b = e.target.closest("[data-lv]"); if (!b || b.disabled) return;
    S.sel = +b.dataset.lv; saveState(); show("home");
  });
  const sw = $("#shakeSw");
  function paintSettings() { sw.setAttribute("aria-pressed", S.shake ? "true" : "false"); }
  paintSettings();
  sw.addEventListener("click", function () { S.shake = !S.shake; paintSettings(); saveState(); });
  $("#resetBtn").addEventListener("click", function () {
    showCard({ eyebrow: "settings", title: "Reset everything?", body: "All unlocks, cheese, best times and attempt counts will be cleared.", cls: "fail",
      acts: [{ t: "reset", danger: true, fn: function () { S.rec = {}; S.unlocked = 1; S.sel = 1; saveState(); hideCard(); show("home"); } }, { t: "cancel", fn: hideCard }] });
  });

  /* ---------------- play ---------------- */
  const hud = $("#hud"), hudFill = $("#hudFill"), hudClock = $("#hudClock");
  function hudInsets() {
    const top = $(".hud-top").getBoundingClientRect().bottom + 4;
    const bot = parseFloat(getComputedStyle(hud).paddingBottom) || 16;
    RENDER.setInsets(top, bot, false);
  }
  function startLevel(n) {
    G.n = n; G.L = getL(n);
    document.body.classList.remove("home");
    DEMO.stop();
    hud.classList.add("on");
    $("#hudLevel").innerHTML = "level <b>" + pad2(n) + "</b> &nbsp;·&nbsp; " + esc(LEVELS[n - 1].name);
    RENDER.setLevel(G.L);
    hudInsets();
    beginRun();
  }
  function beginRun() {
    const r = rec(G.n); r.t++; saveState();
    G.st = SIM.newState(G.L); G.acc = 0; G.paused = false; G.bump = null; G.squash = 0; G.mode = "play";
    RENDER.setLevel(G.L); RENDER.anim.ang = 0;
    hideCard(); paintHud(true);
  }
  let lastClock = "", lastDanger = null;
  function paintHud(force) {
    if (!G.st) return;
    const left = (LIMIT - G.st.t) / HZ, txt = clockText(left), danger = left <= 10 && G.st.out !== "win";
    if (txt !== lastClock || force) { hudClock.textContent = txt; lastClock = txt; }
    if (danger !== lastDanger || force) { hud.classList.toggle("danger", danger); lastDanger = danger; }
    hudFill.style.transform = "scaleX(" + Math.max(0, Math.min(1, left / 60)).toFixed(4) + ")";
  }
  function tryMove(d) {
    if (G.mode !== "play" || G.paused || G.cardUp || !G.st || G.st.out || G.st.sl) return;
    SIM.move(G.L, G.st, d);
    onEvents();
  }
  const WHY = {
    trail: ["crossed your own trail", "Trail crossed", "The rat can't stop mid-slide: plan each slide so it never runs back over the trail."],
    trap: ["snapped by a mousetrap", "Snap!", ""], robot: ["vacuumed up", "Vacuumed", ""], paw: ["caught by the cat", "Swiped!", ""],
    laser: ["zapped by a laser", "Zapped", ""], snake: ["the snake got you", "Bitten", ""], chaser: ["the chaser caught you", "Caught", ""],
    time: ["the clock ran out", "Out of time", ""], stuck: ["no way out", "Trapped", "Every way out is a wall or your own trail."]
  };
  function onEvents() {
    const st = G.st, ev = st.ev; if (!ev || !ev.length) return;
    const p = SIM.ratPos(G.L, st, 0), x = p[0] + 0.5, y = p[1] + 0.5;
    for (const e of ev) {
      switch (e.e) {
        case "bump": G.bump = { d: e.d, t: 0 }; if (S.shake) RENDER.shake(0.25); break;
        case "stop": G.squash = Math.min(1, 0.3 + e.n * 0.08); RENDER.emit(x + SIM.DX[e.d] * 0.38, y + SIM.DY[e.d] * 0.38, 4 + Math.min(8, e.n), { sp: 1.8, life: 0.4, sz: 0.05 }); break;
        case "crack": { const i = e.i; RENDER.emit(i % G.L.w + 0.5, (i / G.L.w | 0) + 0.5, 10, { sp: 2, life: 0.5, sz: 0.06, col: "#3A3A48" }); break; }
        case "splash": RENDER.emit(x, y, 6, { sp: 2.2, life: 0.4, sz: 0.05, col: "rgba(64,150,230,.8)" }); break;
        case "plate": RENDER.emit(x, y, 8, { sp: 1.6, life: 0.5, sz: 0.05, col: "#2F80ED" }); break;
        case "portal": { const b = e.b; RENDER.emit(b % G.L.w + 0.5, (b / G.L.w | 0) + 0.5, 10, { sp: 2, life: 0.45, sz: 0.05, col: "#9B51E0" }); break; }
        case "fan": RENDER.emit(x, y, 4, { sp: 1.2, life: 0.3, sz: 0.04, col: "#FF6A13" }); break;
        case "win": win(); break;
        case "die": die(e.why, e.hit); break;
      }
    }
    ev.length = 0;
  }
  function die(why, hitTile) {
    if (G.mode !== "play") return;
    G.mode = "dead"; G.deadAt = now();
    const st = G.st, ri = st.y * G.L.w + st.x;
    RENDER.hit(why === "trail" ? hitTile : why === "time" || why === "stuck" ? -1 : ri, why);
    if (why === "trap") RENDER.snapTrap(ri);
    if (S.shake) RENDER.shake(why === "time" ? 0.4 : 1);
    if (navigator.vibrate && S.shake) try { navigator.vibrate(60); } catch (e) {}
    const n = G.n, w = WHY[why] || ["failed", "Failed", ""];
    setTimeout(function () {
      if (G.mode !== "dead" || G.n !== n) return;
      showCard({ cls: "fail", eyebrow: "level " + pad2(n) + "  ·  " + w[0], title: w[1], body: w[2] || "",
        stats: [[rec(n).t, "attempts"]].concat(rec(n).d ? [[clockText(rec(n).b, true), "best time"]] : []),
        acts: [{ t: "retry", solid: true, fn: function () { beginRun(); } }, { t: "home", fn: goHome }] });
    }, why === "time" ? 400 : 750);
  }
  function win() {
    if (G.mode !== "play") return;
    G.mode = "won"; G.wonAt = now();
    const st = G.st, n = G.n, taken = st.t / HZ, left = (LIMIT - st.t) / HZ, v = cheeseFor(left);
    const r = rec(n), firstClear = !r.d, newBest = !r.d || taken < r.b - 1e-9;
    r.d = true; r.s = Math.max(r.s || 0, v); if (newBest) r.b = +taken.toFixed(3);
    if (n < N && S.unlocked < n + 1) S.unlocked = n + 1;
    saveState();
    const c = G.L.cheese; RENDER.emit(c % G.L.w + 0.5, (c / G.L.w | 0) + 0.5, 34, { sp: 4, life: 1, sz: 0.07, col: "#FFC83A" });
    setTimeout(function () {
      if (G.mode !== "won" || G.n !== n) return;
      const acts = [];
      if (n < N) acts.push({ t: "next", solid: true, fn: function () { S.sel = n + 1; saveState(); startLevel(n + 1); } });
      acts.push({ t: "retry", solid: n >= N, fn: function () { beginRun(); } });
      acts.push({ t: "home", fn: function () { if (n < N) S.sel = n + 1; saveState(); goHome(); } });
      showCard({ eyebrow: "level " + pad2(n) + " cleared" + (n >= N ? "  ·  all done" : firstClear && n < N ? "  ·  level " + pad2(n + 1) + " unlocked" : ""), title: esc(LEVELS[n - 1].name), stars: v,
        stats: [[clockText(taken, true), "time"], [clockText(r.b, true), newBest && !firstClear ? "new best" : "best", newBest && !firstClear], [clockText(left), "left"]], acts: acts });
    }, 900);
  }
  function goHome() { hideCard(); G.paused = false; show("home"); startHome(); }

  /* ---------------- pause ---------------- */
  function pauseGame() {
    if (G.mode !== "play" || G.paused || G.cardUp) return;
    G.paused = true;
    showCard({ eyebrow: "level " + pad2(G.n) + "  ·  " + clockText((LIMIT - G.st.t) / HZ) + " left", title: "Paused",
      acts: [{ t: "resume", solid: true, fn: resumeGame }, { t: "restart", fn: function () { beginRun(); } }, { t: "home", fn: goHome }] });
  }
  function resumeGame() { if (!G.paused) return; hideCard(true); G.paused = false; G.acc = 0; }
  $("#pauseBtn").addEventListener("click", function (e) { e.stopPropagation(); pauseGame(); });
  document.addEventListener("visibilitychange", function () { if (document.hidden) pauseGame(); });
  window.addEventListener("blur", pauseGame);

  /* ---------------- input ---------------- */
  const KEYS = { ArrowUp: [0, -1], KeyW: [0, -1], ArrowDown: [0, 1], KeyS: [0, 1], ArrowLeft: [-1, 0], KeyA: [-1, 0], ArrowRight: [1, 0], KeyD: [1, 0] };
  window.addEventListener("keydown", function (e) {
    const c = e.code;
    if (c === "Escape" || (c === "KeyP" && G.mode === "play")) {
      if (G.mode === "play" && !G.paused && !G.cardUp) pauseGame();
      else if (G.paused) resumeGame();
      else if (!G.cardUp && panelOn()) show("home");
      else if (G.cardUp && G.mode === "home") hideCard();
      return;
    }
    if (c === "KeyR" && (G.mode === "play" || G.mode === "dead" || G.mode === "won")) { e.preventDefault(); beginRun(); return; }
    if (G.cardUp) { if ((c === "Enter" || c === "Space") && cardActs[0] && !e.repeat && now() - cardAt >= CARD_ARM) { e.preventDefault(); cardActs[0].fn(); } return; }
    if (G.mode === "play") {
      const v = KEYS[c];
      if (v) { e.preventDefault(); if (!e.repeat) tryMove(RENDER.toGrid(v[0], v[1])); }
    } else if (G.mode === "home" && $("#home").classList.contains("on")) {
      if (c === "Enter" || c === "Space") { e.preventDefault(); launch(); }
      else if (c === "ArrowLeft" || c === "KeyA") browse(-1); else if (c === "ArrowRight" || c === "KeyD") browse(1);
    }
  });
  /* swipe (touch) or drag (mouse): one move per gesture, once it has gone SWIPE px */
  const SWIPE = 24, cv = $("#cv");
  let ptr = null;
  cv.addEventListener("pointerdown", function (e) {
    if (G.mode !== "play") return;
    e.preventDefault();
    try { cv.setPointerCapture(e.pointerId); } catch (err) {}
    ptr = { id: e.pointerId, x: e.clientX, y: e.clientY, done: false };
  }, { passive: false });
  cv.addEventListener("pointermove", function (e) {
    if (!ptr || ptr.id !== e.pointerId || ptr.done) return;
    const dx = e.clientX - ptr.x, dy = e.clientY - ptr.y;
    if (dx * dx + dy * dy < SWIPE * SWIPE) return;
    ptr.done = true;
    tryMove(RENDER.toGrid(dx, dy));
  });
  const up = function (e) { if (ptr && ptr.id === e.pointerId) ptr = null; };
  cv.addEventListener("pointerup", up); cv.addEventListener("pointercancel", up);
  document.addEventListener("contextmenu", function (e) { e.preventDefault(); });
  document.addEventListener("gesturestart", function (e) { e.preventDefault(); });

  /* ---------------- main loop ---------------- */
  let last = 0, slow = 0, lowQ = false;
  function loop(ts) {
    requestAnimationFrame(loop);
    const t = ts / 1000, dt = Math.min(0.05, Math.max(0.001, t - last)); last = t;
    if (G.mode === "home" || G.mode === "launch") { DEMO.update(dt); DEMO.draw(t, dt); return; }
    const st = G.st; if (!st) return;
    if (G.mode === "play" && !G.paused) {
      G.acc += dt;
      let n = 0;
      while (G.acc >= 1 / HZ && n++ < 8) { G.acc -= 1 / HZ; SIM.step(G.L, st); onEvents(); if (st.out || G.mode !== "play") break; }
      if (G.acc > 0.2) G.acc = 0;
      paintHud(false);
    }
    if (G.bump) { G.bump.t += dt; if (G.bump.t > 0.2) G.bump = null; }
    G.squash = Math.max(0, G.squash - dt * 6);
    const live = G.mode === "play" && !G.paused && !st.out;
    RENDER.frame({ st: st, sub: live ? G.acc * HZ : 0, t: t, dt: G.paused ? 0 : dt, home: false, won: G.mode === "won", wonT: G.mode === "won" ? now() - G.wonAt : 0,
      noShake: !S.shake, bump: G.bump, squash: G.squash });
    /* drop resolution once if the device cannot hold 60 fps */
    if (G.mode === "play" && !G.paused && !lowQ) { slow = dt > 0.024 ? slow + 1 : Math.max(0, slow - 0.25); if (slow > 90) { lowQ = true; RENDER.setQuality(0.75); } }
  }

  /* ---------------- boot ---------------- */
  const imgs = { rat: new Image(), cheese: new Image() };
  imgs.rat.src = "assets/rat.png"; imgs.cheese.src = "assets/cheese.png";
  RENDER.init(cv, imgs);
  let rz = 0;
  const onResize = function () {
    clearTimeout(rz);
    rz = setTimeout(function () { RENDER.resize(); if (G.mode === "home" || G.mode === "launch") RENDER.setInsets(0, 0, true); else hudInsets(); }, 100);
  };
  window.addEventListener("resize", onResize);
  window.addEventListener("orientationchange", function () { setTimeout(onResize, 160); });
  startHome(); show("home");
  requestAnimationFrame(loop);
  /* a handle for tests and the console */
  window.__TRAPPEDRAT = { G: G, S: function () { return S; }, startLevel: startLevel, beginRun: beginRun, tryMove: tryMove, show: show, goHome: goHome,
    cheeseFor: cheeseFor, RATING: RATING, saveState: saveState, setS: function (o) { S = checkState(o || {}); saveState(); return S; } };
})();
