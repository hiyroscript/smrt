/* ---- solver.js ----
   SOLVER: finds the fastest way to the cheese by searching over real simulated moves (sim.js), so slides, the
   no-recrossing rule and every obstacle's timing are exactly the game's. Best-first on the level clock (Dijkstra):
   the first winning state popped is the fastest. A state is the rat's tile, its trail (a 64-bit Zobrist hash), the
   fans' arrows and the chaser's tile; reaching one again later is pruned (arriving earlier and waiting covers it).

   Moves are spaced like a person plays: at least MIN_WAIT ticks between the end of one slide and the next swipe. On
   a level with timed obstacles the solver also tries waiting longer, in WAIT_STEP steps up to MAX_WAIT. Solutions
   are [[waitTicks, dir], ...] and replay exactly (SIM.replay), which is how the home demo plays them.

   Also here: the difficulty measure used by the generator and tools/difficulty.js. */
(function (root) {
  "use strict";
  const SIM = root.SIM || (typeof require !== "undefined" ? require("./sim.js") : null);
  const MIN_WAIT = 15, WAIT_STEP = 12, MAX_WAIT = 180;

  function key(st) {
    let s = st.x + "," + st.y + "," + st.h1 + "," + st.h2;
    if (st.fan.length) s += "," + st.fan.join("");
    if (st.ch) s += "," + st.ch.i;
    return s;
  }
  /* a small binary heap on (t, moves) */
  function Heap() { this.a = []; }
  Heap.prototype.less = function (x, y) { return x.st.t < y.st.t || (x.st.t === y.st.t && x.st.moves < y.st.moves); };
  Heap.prototype.push = function (n) {
    const a = this.a; a.push(n); let i = a.length - 1;
    while (i > 0) { const p = (i - 1) >> 1; if (!this.less(a[i], a[p])) break; const t = a[i]; a[i] = a[p]; a[p] = t; i = p; }
  };
  Heap.prototype.pop = function () {
    const a = this.a, top = a[0], last = a.pop();
    if (a.length) {
      a[0] = last; let i = 0;
      for (;;) {
        const l = 2 * i + 1, r = l + 1; let m = i;
        if (l < a.length && this.less(a[l], a[m])) m = l;
        if (r < a.length && this.less(a[r], a[m])) m = r;
        if (m === i) break; const t = a[i]; a[i] = a[m]; a[m] = t; i = m;
      }
    }
    return top;
  };

  /* opt: from (a state to start from, default the level start), firstDir (only this direction for the first move),
     max (states to expand before giving up) */
  function solve(L, opt) {
    opt = opt || {};
    const start = opt.from ? SIM.clone(opt.from) : SIM.newState(L, true);
    const max = opt.max || 250000;
    const waits = [];
    if (L.timed) for (let w = MIN_WAIT; w <= MIN_WAIT + MAX_WAIT; w += WAIT_STEP) waits.push(w); else waits.push(MIN_WAIT);
    const doors = L.doors.length > 0;
    const heap = new Heap(), seen = new Set();
    const root0 = { st: start, par: null, mv: null };
    heap.push(root0);
    let expanded = 0;
    while (heap.a.length) {
      const node = heap.pop(), st = node.st;
      if (st.out === "win") return build(node, expanded);
      const k = key(st);
      if (seen.has(k)) continue;
      seen.add(k);
      if (++expanded > max) return null;
      const dirs = node === root0 && opt.firstDir !== undefined ? [opt.firstDir] : [0, 1, 2, 3];
      const done = [false, false, false, false], made = new Set();
      const idle = SIM.clone(st);
      let waited = 0;
      for (const w of waits) {
        while (waited < w && !idle.out) { SIM.step(L, idle); waited++; }
        if (idle.out) break;   /* caught while waiting: waiting longer won't help */
        let any = false;
        for (const d of dirs) {
          if (done[d]) continue;
          any = true;
          const c = SIM.clone(idle);
          if (SIM.move(L, c, d) !== "move") { done[d] = true; continue; }
          while (c.sl && !c.out) SIM.step(L, c);
          if (c.out && c.out !== "win") continue;
          /* the end state is the same whatever the wait unless a door changed it: keep only the earliest */
          if (!doors) done[d] = true;
          const kk = c.out === "win" ? "win" : key(c);
          if (made.has(kk)) continue;
          made.add(kk);
          heap.push({ st: c, par: node, mv: [w, d] });
        }
        if (!any) break;
      }
    }
    return null;
  }
  function build(node, expanded) {
    const moves = [], states = [];
    let t = node.st.t;
    for (let n = node; n.par; n = n.par) { moves.push(n.mv); states.push(n.par.st); }
    moves.reverse(); states.reverse();
    return { moves: moves, states: states, t: t, sec: t / SIM.HZ, expanded: expanded };
  }

  /* wrong turns along the fastest route: at each stop, every other direction that does something (not a bump, not
     straight back onto the trail) but from which no way to the cheese exists */
  function traps(L, sol, budget) {
    let n = 0;
    for (let i = 0; i < sol.states.length; i++) {
      const s0 = sol.states[i], taken = sol.moves[i][1];
      for (let d = 0; d < 4; d++) {
        if (d === taken) continue;
        const c = SIM.clone(s0);
        for (let k = 0; k < MIN_WAIT && !c.out; k++) SIM.step(L, c);
        if (c.out || SIM.move(L, c, d) !== "move") continue;
        if (c.sl.n === 0 && c.sl.out === "trail") continue;
        if (!solve(L, { from: s0, firstDir: d, max: budget || 30000 })) n++;
      }
    }
    return n;
  }

  /* ---------------- difficulty ----------------
     route  = moves + traps + 0.6·√(floor tiles)              (moves and wrong turns on the fastest route, and maze size)
     hazard = 1 + 0.05·Σ obstacle weights                 (each obstacle's weight grows with its speed / tightness)
     clock  = 1 + 1.0·(solution time / 60 s)              (how much of the time window the best route needs)
     D = route · hazard · clock
   The generator tunes every level to D(n) = D1 · 1.1^(n−1) within ±3 % (it aims for ±1 %). */
  const D1 = 5, GROWTH = 1.1;
  const W = { trap: 1.2, glue: 1.0, puddle: 1.6, crack: 1.6, conv: 1.4, portal: 2.4, door: 2.4, plate: 2.6, gate: 0, fan: 2.6,
    laser: 2.8, paw: 2.6, robot: 2.0, snake: 3.2, chaser: 6.0 };
  function obstacleWeight(def) {
    let s = 0;
    for (const o of def.obs || []) {
      let w = W[o.k] || 0;
      if (o.k === "robot") w += 0.9 * o.v;                         /* tiles per second */
      else if (o.k === "snake") w += 0.7 * o.v + 0.4 * o.len;
      else if (o.k === "door") w += 2.0 / o.p;                     /* faster doors: tighter windows */
      else if (o.k === "paw") w += 2.0 / o.p;
      else if (o.k === "laser") w += 1.5 * o.on / (o.on + o.off);  /* longer on-time */
      s += w;
    }
    return s;
  }
  function measure(def, L, sol) {
    L = L || SIM.compile(def);
    sol = sol || solve(L);
    if (!sol) return null;
    const m = { moves: sol.moves.length, traps: traps(L, sol), tiles: L.floor, haz: obstacleWeight(def), time: sol.sec };
    m.score = score(m);
    return m;
  }
  function score(m) { return (m.moves + m.traps + 0.6 * Math.sqrt(m.tiles)) * (1 + 0.05 * m.haz) * (1 + m.time / 60); }
  function target(n) { return D1 * Math.pow(GROWTH, n - 1); }

  const SOLVER = { solve: solve, traps: traps, measure: measure, score: score, target: target, obstacleWeight: obstacleWeight,
    key: key, MIN_WAIT: MIN_WAIT, WAIT_STEP: WAIT_STEP, MAX_WAIT: MAX_WAIT, D1: D1, GROWTH: GROWTH,
    /* the demo's route for a level: the committed one when there is one, else solved now */
    route: function (L) { return L.def.sol || (solve(L) || { moves: [] }).moves; } };
  if (typeof module !== "undefined" && module.exports) module.exports = SOLVER; else root.SOLVER = SOLVER;
})(this);
